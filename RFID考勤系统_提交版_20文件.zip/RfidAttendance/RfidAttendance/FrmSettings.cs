﻿// 设备设置页
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Hardware;
using RfidAttendance.Models;
using RfidAttendance.Services;

// ---------------------------------------------------------------
// 来源：Forms\FrmSettings.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 设备设置页：读卡器串口连接、发射功率、防重复刷卡间隔，以及数据目录等运维入口。
    /// </summary>
    public partial class FrmSettings : Form, IPageView
    {
        private readonly FrmMain _main;
        private readonly EmployeeRepository _employeeRepo = new EmployeeRepository();

        /// <summary>供 Visual Studio 设计器使用。</summary>
        public FrmSettings()
            : this(null)
        {
        }

        public FrmSettings(FrmMain main)
        {
            InitializeComponent();
            _main = main;
            AppTheme.ApplyForm(this);

            AppTheme.StylePrimaryButton(btnConnect);
            AppTheme.StyleSecondaryButton(btnApplyPower);
            AppTheme.StyleSecondaryButton(btnSaveDup);
            AppTheme.StyleSecondaryButton(btnOpenData);
            AppTheme.StyleSecondaryButton(btnOpenLog);
            AppTheme.StyleSecondaryButton(btnSeed);

            btnConnect.Click += btnConnect_Click;
            btnApplyPower.Click += btnApplyPower_Click;
            btnSaveDup.Click += btnSaveDup_Click;
            btnOpenData.Click += btnOpenData_Click;
            btnOpenLog.Click += btnOpenLog_Click;
            btnSeed.Click += btnSeed_Click;

            Load += OnSettingsLoad;
            FormClosed += OnSettingsClosed;
        }

        #region 生命周期

        private void OnSettingsLoad(object sender, EventArgs e)
        {
            LoadPortList();
            LoadBaudList();
            LoadSavedSettings();

            labDbPath.Text = "数据库：" + DbHelper.DatabasePath +
                             "\r\n日志：  " + AppLog.LogDirectory;

            RfidReaderService.Instance.StatusChanged += OnReaderStatusChanged;
            UpdateReaderUi();
        }

        private void OnSettingsClosed(object sender, EventArgs e)
        {
            RfidReaderService.Instance.StatusChanged -= OnReaderStatusChanged;
        }

        public void OnPageShown()
        {
            UpdateReaderUi();
        }

        #endregion

        #region 初始化下拉框

        private void LoadPortList()
        {
            cmbPort.Items.Clear();
            cmbPort.Items.Add("自动搜索");

            // 已存在的真实串口优先列出
            try
            {
                string[] names = SerialPort.GetPortNames();
                Array.Sort(names);
                for (int i = 0; i < names.Length; i++)
                {
                    if (!cmbPort.Items.Contains(names[i]))
                    {
                        cmbPort.Items.Add(names[i]);
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("枚举串口失败：" + ex.Message);
            }

            // 没有装驱动时也要能手动指定
            for (int i = 1; i <= 30; i++)
            {
                string name = "COM" + i;
                if (!cmbPort.Items.Contains(name))
                {
                    cmbPort.Items.Add(name);
                }
            }

            cmbPort.SelectedIndex = 0;
        }

        private void LoadBaudList()
        {
            cmbBaud.Items.Clear();
            for (int i = 0; i < RfidReaderService.BaudRateTexts.Length; i++)
            {
                cmbBaud.Items.Add(RfidReaderService.BaudRateTexts[i]);
            }
            cmbBaud.SelectedIndex = 3;
        }

        private void LoadSavedSettings()
        {
            try
            {
                string port = SettingsStore.Get(SettingsStore.KeyPort, string.Empty);
                if (!string.IsNullOrEmpty(port))
                {
                    int index = cmbPort.Items.IndexOf(port);
                    if (index >= 0)
                    {
                        cmbPort.SelectedIndex = index;
                    }
                }

                int baud = SettingsStore.GetInt(SettingsStore.KeyBaudIndex, 3);
                if (baud >= 0 && baud < cmbBaud.Items.Count)
                {
                    cmbBaud.SelectedIndex = baud;
                }

                int power = SettingsStore.GetInt(SettingsStore.KeyPowerDbm, 26);
                if (power >= numPower.Minimum && power <= numPower.Maximum)
                {
                    numPower.Value = power;
                }

                int dup = SettingsStore.GetInt(SettingsStore.KeyDuplicateSeconds, 30);
                if (dup >= numDuplicate.Minimum && dup <= numDuplicate.Maximum)
                {
                    numDuplicate.Value = dup;
                }
            }
            catch (Exception ex)
            {
                AppLog.Warn("读取已保存的设置失败：" + ex.Message);
            }
        }

        #endregion

        #region 读卡器连接

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (_main == null)
            {
                return;
            }

            btnConnect.Enabled = false;
            Cursor = Cursors.WaitCursor;
            Application.DoEvents();

            try
            {
                if (_main.Reader.IsOpen)
                {
                    _main.DisconnectReader();
                    AppLog.Info("用户手动断开读卡器");
                }
                else
                {
                    string port = cmbPort.SelectedIndex <= 0 ? string.Empty : cmbPort.SelectedItem.ToString();
                    int baud = cmbBaud.SelectedIndex < 0 ? 3 : cmbBaud.SelectedIndex;

                    string error;
                    if (_main.ConnectReader(port, baud, out error))
                    {
                        SettingsStore.Set(SettingsStore.KeyPort, port);
                        SettingsStore.SetInt(SettingsStore.KeyBaudIndex, baud);

                        // 连接成功后顺手把功率设置也下发一次
                        byte power = (byte)numPower.Value;
                        _main.Reader.SetPowerDbm(power);
                    }
                    else
                    {
                        MessageBox.Show(this, error, "连接失败",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("连接/断开读卡器异常", ex);
                MessageBox.Show(this, "操作失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
                btnConnect.Enabled = true;
                UpdateReaderUi();
            }
        }

        private void OnReaderStatusChanged(object sender, ReaderStatusEventArgs e)
        {
            if (!IsHandleCreated || IsDisposed)
            {
                return;
            }
            try
            {
                BeginInvoke(new Action(UpdateReaderUi));
            }
            catch (InvalidOperationException)
            {
            }
        }

        private void UpdateReaderUi()
        {
            bool open = _main != null && _main.Reader.IsOpen;

            btnConnect.Text = open ? "断开连接" : "连接读卡器";

            if (open)
            {
                labReaderInfo.ForeColor = AppTheme.Success;
                labReaderInfo.Text = string.Format("状态：已连接 {0}（{1}）　{2}",
                    _main.Reader.PortName, _main.Reader.BaudText, _main.Reader.ReaderType);
            }
            else
            {
                labReaderInfo.ForeColor = AppTheme.TextSecondary;
                labReaderInfo.Text = "状态：未连接";
            }

            cmbPort.Enabled = !open;
            cmbBaud.Enabled = !open;
            numPower.Enabled = open;
            btnApplyPower.Enabled = open;
        }

        #endregion

        #region 功率与防抖

        private void btnApplyPower_Click(object sender, EventArgs e)
        {
            if (_main == null || !_main.Reader.IsOpen)
            {
                MessageBox.Show(this, "请先连接读卡器。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            byte power = (byte)numPower.Value;
            if (_main.Reader.SetPowerDbm(power))
            {
                SettingsStore.SetInt(SettingsStore.KeyPowerDbm, power);
                MessageBox.Show(this, "已把发射功率设置为 " + power + " dBm。", "设置成功",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show(this, "设置功率失败，请检查读卡器连接。", "设置失败",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSaveDup_Click(object sender, EventArgs e)
        {
            int seconds = (int)numDuplicate.Value;
            SettingsStore.SetInt(SettingsStore.KeyDuplicateSeconds, seconds);

            MessageBox.Show(this,
                "防重复刷卡间隔已保存为 " + seconds + " 秒。\r\n\r\n" +
                "设置会在下次启动打卡页时生效。",
                "已保存", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        #endregion

        #region 数据与日志

        private void btnOpenData_Click(object sender, EventArgs e)
        {
            OpenFolder(Path.GetDirectoryName(DbHelper.DatabasePath));
        }

        private void btnOpenLog_Click(object sender, EventArgs e)
        {
            OpenFolder(AppLog.LogDirectory);
        }

        private void OpenFolder(string path)
        {
            try
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                Process.Start("explorer.exe", "\"" + path + "\"");
            }
            catch (Exception ex)
            {
                AppLog.Error("打开目录失败：" + path, ex);
                MessageBox.Show(this, "打开目录失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>插入几名演示员工，方便在没有硬件时走通整个流程。</summary>
        private void btnSeed_Click(object sender, EventArgs e)
        {
            string message =
                "将插入 3 名演示员工（张三 / 李四 / 王五），每人带一个测试卡号：\r\n\r\n" +
                "D001 张三  E2003412A1B2C3D4\r\n" +
                "D002 李四  E2003412A1B2C3D5\r\n" +
                "D003 王五  E2003412A1B2C3D6\r\n\r\n" +
                "这些都不是真实人员信息，仅用于功能演示。是否继续？";

            if (MessageBox.Show(this, message, "生成演示数据",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question) != DialogResult.OK)
            {
                return;
            }

            string[][] seeds = new string[][]
            {
                new string[] { "D001", "张三", "技术部",   "工程师",   "E2003412A1B2C3D4" },
                new string[] { "D002", "李四", "行政部",   "行政专员", "E2003412A1B2C3D5" },
                new string[] { "D003", "王五", "市场部",   "市场专员", "E2003412A1B2C3D6" }
            };

            int added = 0;
            int skipped = 0;

            try
            {
                for (int i = 0; i < seeds.Length; i++)
                {
                    string[] row = seeds[i];

                    if (_employeeRepo.EmpNoExists(row[0], 0))
                    {
                        skipped++;
                        continue;
                    }

                    Employee emp = new Employee();
                    emp.EmpNo = row[0];
                    emp.Name = row[1];
                    emp.Department = row[2];
                    emp.Position = row[3];
                    emp.CardNo = row[4];
                    emp.IsActive = true;
                    _employeeRepo.Insert(emp);
                    added++;
                }

                MessageBox.Show(this,
                    string.Format("完成：新增 {0} 名，跳过 {1} 名（工号已存在）。\r\n\r\n现在可以到打卡页用「手动输入卡号」试试。",
                        added, skipped),
                    "生成完成", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                AppLog.Error("生成演示数据失败", ex);
                MessageBox.Show(this, "生成失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmSettings.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmSettings
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelReader = new System.Windows.Forms.Panel();
            this.labReaderTitle = new System.Windows.Forms.Label();
            this.labPort = new System.Windows.Forms.Label();
            this.cmbPort = new System.Windows.Forms.ComboBox();
            this.labBaud = new System.Windows.Forms.Label();
            this.cmbBaud = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.labReaderInfo = new System.Windows.Forms.Label();
            this.labReaderHint = new System.Windows.Forms.Label();
            this.panelPower = new System.Windows.Forms.Panel();
            this.labPowerTitle = new System.Windows.Forms.Label();
            this.labPowerValue = new System.Windows.Forms.Label();
            this.numPower = new System.Windows.Forms.NumericUpDown();
            this.btnApplyPower = new System.Windows.Forms.Button();
            this.labPowerHint = new System.Windows.Forms.Label();
            this.panelExtra = new System.Windows.Forms.Panel();
            this.labExtraTitle = new System.Windows.Forms.Label();
            this.labDup = new System.Windows.Forms.Label();
            this.numDuplicate = new System.Windows.Forms.NumericUpDown();
            this.labDupUnit = new System.Windows.Forms.Label();
            this.btnSaveDup = new System.Windows.Forms.Button();
            this.labDupHint = new System.Windows.Forms.Label();
            this.panelDb = new System.Windows.Forms.Panel();
            this.labDbTitle = new System.Windows.Forms.Label();
            this.labDbPath = new System.Windows.Forms.Label();
            this.btnOpenData = new System.Windows.Forms.Button();
            this.btnOpenLog = new System.Windows.Forms.Button();
            this.btnSeed = new System.Windows.Forms.Button();
            this.labSeedHint = new System.Windows.Forms.Label();
            this.panelReader.SuspendLayout();
            this.panelPower.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPower)).BeginInit();
            this.panelExtra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDuplicate)).BeginInit();
            this.panelDb.SuspendLayout();
            this.SuspendLayout();
            //
            // panelReader
            //
            this.panelReader.BackColor = System.Drawing.Color.White;
            this.panelReader.Controls.Add(this.labReaderTitle);
            this.panelReader.Controls.Add(this.labPort);
            this.panelReader.Controls.Add(this.cmbPort);
            this.panelReader.Controls.Add(this.labBaud);
            this.panelReader.Controls.Add(this.cmbBaud);
            this.panelReader.Controls.Add(this.btnConnect);
            this.panelReader.Controls.Add(this.labReaderInfo);
            this.panelReader.Controls.Add(this.labReaderHint);
            this.panelReader.Location = new System.Drawing.Point(0, 0);
            this.panelReader.Name = "panelReader";
            this.panelReader.Size = new System.Drawing.Size(948, 186);
            this.panelReader.TabIndex = 0;
            //
            // labReaderTitle
            //
            this.labReaderTitle.AutoSize = true;
            this.labReaderTitle.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Bold);
            this.labReaderTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labReaderTitle.Location = new System.Drawing.Point(24, 18);
            this.labReaderTitle.Name = "labReaderTitle";
            this.labReaderTitle.Size = new System.Drawing.Size(84, 20);
            this.labReaderTitle.TabIndex = 0;
            this.labReaderTitle.Text = "读卡器连接";
            //
            // labPort
            //
            this.labPort.AutoSize = true;
            this.labPort.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labPort.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labPort.Location = new System.Drawing.Point(26, 65);
            this.labPort.Name = "labPort";
            this.labPort.Size = new System.Drawing.Size(32, 17);
            this.labPort.TabIndex = 1;
            this.labPort.Text = "串口";
            //
            // cmbPort
            //
            this.cmbPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPort.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.cmbPort.Location = new System.Drawing.Point(74, 61);
            this.cmbPort.Name = "cmbPort";
            this.cmbPort.Size = new System.Drawing.Size(180, 25);
            this.cmbPort.TabIndex = 2;
            //
            // labBaud
            //
            this.labBaud.AutoSize = true;
            this.labBaud.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labBaud.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labBaud.Location = new System.Drawing.Point(278, 65);
            this.labBaud.Name = "labBaud";
            this.labBaud.Size = new System.Drawing.Size(44, 17);
            this.labBaud.TabIndex = 3;
            this.labBaud.Text = "波特率";
            //
            // cmbBaud
            //
            this.cmbBaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBaud.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.cmbBaud.Location = new System.Drawing.Point(332, 61);
            this.cmbBaud.Name = "cmbBaud";
            this.cmbBaud.Size = new System.Drawing.Size(140, 25);
            this.cmbBaud.TabIndex = 4;
            //
            // btnConnect
            //
            this.btnConnect.Location = new System.Drawing.Point(494, 59);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(140, 30);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Text = "连接读卡器";
            this.btnConnect.UseVisualStyleBackColor = true;
            //
            // labReaderInfo
            //
            this.labReaderInfo.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labReaderInfo.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labReaderInfo.Location = new System.Drawing.Point(26, 104);
            this.labReaderInfo.Name = "labReaderInfo";
            this.labReaderInfo.Size = new System.Drawing.Size(896, 24);
            this.labReaderInfo.TabIndex = 6;
            this.labReaderInfo.Text = "状态：未连接";
            //
            // labReaderHint
            //
            this.labReaderHint.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labReaderHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labReaderHint.Location = new System.Drawing.Point(26, 132);
            this.labReaderHint.Name = "labReaderHint";
            this.labReaderHint.Size = new System.Drawing.Size(896, 40);
            this.labReaderHint.TabIndex = 7;
            this.labReaderHint.Text = "读卡器通过 USB 转串口（CP210x）连接，装好驱动后会出现一个 COM 口。选「自动搜索」让程序自己找。";
            //
            // panelPower
            //
            this.panelPower.BackColor = System.Drawing.Color.White;
            this.panelPower.Controls.Add(this.labPowerTitle);
            this.panelPower.Controls.Add(this.labPowerValue);
            this.panelPower.Controls.Add(this.numPower);
            this.panelPower.Controls.Add(this.btnApplyPower);
            this.panelPower.Controls.Add(this.labPowerHint);
            this.panelPower.Location = new System.Drawing.Point(0, 198);
            this.panelPower.Name = "panelPower";
            this.panelPower.Size = new System.Drawing.Size(460, 172);
            this.panelPower.TabIndex = 1;
            //
            // labPowerTitle
            //
            this.labPowerTitle.AutoSize = true;
            this.labPowerTitle.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Bold);
            this.labPowerTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labPowerTitle.Location = new System.Drawing.Point(20, 16);
            this.labPowerTitle.Name = "labPowerTitle";
            this.labPowerTitle.Size = new System.Drawing.Size(84, 20);
            this.labPowerTitle.TabIndex = 0;
            this.labPowerTitle.Text = "发射功率";
            //
            // labPowerValue
            //
            this.labPowerValue.AutoSize = true;
            this.labPowerValue.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labPowerValue.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labPowerValue.Location = new System.Drawing.Point(22, 62);
            this.labPowerValue.Name = "labPowerValue";
            this.labPowerValue.Size = new System.Drawing.Size(56, 17);
            this.labPowerValue.TabIndex = 1;
            this.labPowerValue.Text = "功率(dBm)";
            //
            // numPower
            //
            this.numPower.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.numPower.Location = new System.Drawing.Point(102, 58);
            this.numPower.Maximum = new decimal(new int[] { 30, 0, 0, 0 });
            this.numPower.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numPower.Name = "numPower";
            this.numPower.Size = new System.Drawing.Size(84, 25);
            this.numPower.TabIndex = 2;
            this.numPower.Value = new decimal(new int[] { 26, 0, 0, 0 });
            //
            // btnApplyPower
            //
            this.btnApplyPower.Location = new System.Drawing.Point(198, 56);
            this.btnApplyPower.Name = "btnApplyPower";
            this.btnApplyPower.Size = new System.Drawing.Size(90, 30);
            this.btnApplyPower.TabIndex = 3;
            this.btnApplyPower.Text = "应用";
            this.btnApplyPower.UseVisualStyleBackColor = true;
            //
            // labPowerHint
            //
            this.labPowerHint.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labPowerHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labPowerHint.Location = new System.Drawing.Point(22, 100);
            this.labPowerHint.Name = "labPowerHint";
            this.labPowerHint.Size = new System.Drawing.Size(420, 56);
            this.labPowerHint.TabIndex = 4;
            this.labPowerHint.Text = "功率越大读得越远，但也更容易读到范围外的卡。桌面打卡场景建议 20~26 dBm。";
            //
            // panelExtra
            //
            this.panelExtra.BackColor = System.Drawing.Color.White;
            this.panelExtra.Controls.Add(this.labExtraTitle);
            this.panelExtra.Controls.Add(this.labDup);
            this.panelExtra.Controls.Add(this.numDuplicate);
            this.panelExtra.Controls.Add(this.labDupUnit);
            this.panelExtra.Controls.Add(this.btnSaveDup);
            this.panelExtra.Controls.Add(this.labDupHint);
            this.panelExtra.Location = new System.Drawing.Point(488, 198);
            this.panelExtra.Name = "panelExtra";
            this.panelExtra.Size = new System.Drawing.Size(460, 172);
            this.panelExtra.TabIndex = 2;
            //
            // labExtraTitle
            //
            this.labExtraTitle.AutoSize = true;
            this.labExtraTitle.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Bold);
            this.labExtraTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labExtraTitle.Location = new System.Drawing.Point(20, 16);
            this.labExtraTitle.Name = "labExtraTitle";
            this.labExtraTitle.Size = new System.Drawing.Size(84, 20);
            this.labExtraTitle.TabIndex = 0;
            this.labExtraTitle.Text = "防重复刷卡";
            //
            // labDup
            //
            this.labDup.AutoSize = true;
            this.labDup.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labDup.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labDup.Location = new System.Drawing.Point(22, 62);
            this.labDup.Name = "labDup";
            this.labDup.Size = new System.Drawing.Size(56, 17);
            this.labDup.TabIndex = 1;
            this.labDup.Text = "间隔(秒)";
            //
            // numDuplicate
            //
            this.numDuplicate.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.numDuplicate.Location = new System.Drawing.Point(102, 58);
            this.numDuplicate.Maximum = new decimal(new int[] { 600, 0, 0, 0 });
            this.numDuplicate.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numDuplicate.Name = "numDuplicate";
            this.numDuplicate.Size = new System.Drawing.Size(84, 25);
            this.numDuplicate.TabIndex = 2;
            this.numDuplicate.Value = new decimal(new int[] { 30, 0, 0, 0 });
            //
            // labDupUnit
            //
            this.labDupUnit.AutoSize = true;
            this.labDupUnit.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labDupUnit.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labDupUnit.Location = new System.Drawing.Point(192, 62);
            this.labDupUnit.Name = "labDupUnit";
            this.labDupUnit.Size = new System.Drawing.Size(20, 17);
            this.labDupUnit.TabIndex = 3;
            this.labDupUnit.Text = "秒";
            //
            // btnSaveDup
            //
            this.btnSaveDup.Location = new System.Drawing.Point(226, 56);
            this.btnSaveDup.Name = "btnSaveDup";
            this.btnSaveDup.Size = new System.Drawing.Size(90, 30);
            this.btnSaveDup.TabIndex = 4;
            this.btnSaveDup.Text = "保存";
            this.btnSaveDup.UseVisualStyleBackColor = true;
            //
            // labDupHint
            //
            this.labDupHint.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labDupHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labDupHint.Location = new System.Drawing.Point(22, 100);
            this.labDupHint.Name = "labDupHint";
            this.labDupHint.Size = new System.Drawing.Size(420, 56);
            this.labDupHint.TabIndex = 5;
            this.labDupHint.Text = "同一位员工在这个时间内重复刷卡会被忽略，避免误刷把「上班」变成「下班」。";
            //
            // panelDb
            //
            this.panelDb.BackColor = System.Drawing.Color.White;
            this.panelDb.Controls.Add(this.labDbTitle);
            this.panelDb.Controls.Add(this.labDbPath);
            this.panelDb.Controls.Add(this.btnOpenData);
            this.panelDb.Controls.Add(this.btnOpenLog);
            this.panelDb.Controls.Add(this.btnSeed);
            this.panelDb.Controls.Add(this.labSeedHint);
            this.panelDb.Location = new System.Drawing.Point(0, 382);
            this.panelDb.Name = "panelDb";
            this.panelDb.Size = new System.Drawing.Size(948, 190);
            this.panelDb.TabIndex = 3;
            //
            // labDbTitle
            //
            this.labDbTitle.AutoSize = true;
            this.labDbTitle.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Bold);
            this.labDbTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labDbTitle.Location = new System.Drawing.Point(24, 16);
            this.labDbTitle.Name = "labDbTitle";
            this.labDbTitle.Size = new System.Drawing.Size(84, 20);
            this.labDbTitle.TabIndex = 0;
            this.labDbTitle.Text = "数据与日志";
            //
            // labDbPath
            //
            this.labDbPath.Font = new System.Drawing.Font("Consolas", 9F);
            this.labDbPath.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labDbPath.Location = new System.Drawing.Point(26, 50);
            this.labDbPath.Name = "labDbPath";
            this.labDbPath.Size = new System.Drawing.Size(896, 44);
            this.labDbPath.TabIndex = 1;
            this.labDbPath.Text = "数据库：—";
            //
            // btnOpenData
            //
            this.btnOpenData.Location = new System.Drawing.Point(26, 104);
            this.btnOpenData.Name = "btnOpenData";
            this.btnOpenData.Size = new System.Drawing.Size(150, 32);
            this.btnOpenData.TabIndex = 2;
            this.btnOpenData.Text = "打开数据目录";
            this.btnOpenData.UseVisualStyleBackColor = true;
            //
            // btnOpenLog
            //
            this.btnOpenLog.Location = new System.Drawing.Point(188, 104);
            this.btnOpenLog.Name = "btnOpenLog";
            this.btnOpenLog.Size = new System.Drawing.Size(150, 32);
            this.btnOpenLog.TabIndex = 3;
            this.btnOpenLog.Text = "打开日志目录";
            this.btnOpenLog.UseVisualStyleBackColor = true;
            //
            // btnSeed
            //
            this.btnSeed.Location = new System.Drawing.Point(350, 104);
            this.btnSeed.Name = "btnSeed";
            this.btnSeed.Size = new System.Drawing.Size(180, 32);
            this.btnSeed.TabIndex = 4;
            this.btnSeed.Text = "生成演示数据";
            this.btnSeed.UseVisualStyleBackColor = true;
            //
            // labSeedHint
            //
            this.labSeedHint.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labSeedHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labSeedHint.Location = new System.Drawing.Point(26, 146);
            this.labSeedHint.Name = "labSeedHint";
            this.labSeedHint.Size = new System.Drawing.Size(896, 34);
            this.labSeedHint.TabIndex = 5;
            this.labSeedHint.Text = "没有硬件时，可以先点「生成演示数据」插入几名测试员工，再用打卡页的「手动输入卡号」功能走通整个流程。";
            //
            // FrmSettings
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.ClientSize = new System.Drawing.Size(948, 592);
            this.Controls.Add(this.panelDb);
            this.Controls.Add(this.panelExtra);
            this.Controls.Add(this.panelPower);
            this.Controls.Add(this.panelReader);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.Name = "FrmSettings";
            this.panelReader.ResumeLayout(false);
            this.panelReader.PerformLayout();
            this.panelPower.ResumeLayout(false);
            this.panelPower.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPower)).EndInit();
            this.panelExtra.ResumeLayout(false);
            this.panelExtra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDuplicate)).EndInit();
            this.panelDb.ResumeLayout(false);
            this.panelDb.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelReader;
        private System.Windows.Forms.Label labReaderTitle;
        private System.Windows.Forms.Label labPort;
        private System.Windows.Forms.ComboBox cmbPort;
        private System.Windows.Forms.Label labBaud;
        private System.Windows.Forms.ComboBox cmbBaud;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label labReaderInfo;
        private System.Windows.Forms.Label labReaderHint;
        private System.Windows.Forms.Panel panelPower;
        private System.Windows.Forms.Label labPowerTitle;
        private System.Windows.Forms.Label labPowerValue;
        private System.Windows.Forms.NumericUpDown numPower;
        private System.Windows.Forms.Button btnApplyPower;
        private System.Windows.Forms.Label labPowerHint;
        private System.Windows.Forms.Panel panelExtra;
        private System.Windows.Forms.Label labExtraTitle;
        private System.Windows.Forms.Label labDup;
        private System.Windows.Forms.NumericUpDown numDuplicate;
        private System.Windows.Forms.Label labDupUnit;
        private System.Windows.Forms.Button btnSaveDup;
        private System.Windows.Forms.Label labDupHint;
        private System.Windows.Forms.Panel panelDb;
        private System.Windows.Forms.Label labDbTitle;
        private System.Windows.Forms.Label labDbPath;
        private System.Windows.Forms.Button btnOpenData;
        private System.Windows.Forms.Button btnOpenLog;
        private System.Windows.Forms.Button btnSeed;
        private System.Windows.Forms.Label labSeedHint;
    }
}
