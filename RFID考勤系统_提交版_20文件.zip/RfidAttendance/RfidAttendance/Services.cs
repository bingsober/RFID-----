﻿// 业务层：考勤判定（上班/下班/防抖）
using System;
using System.Collections.Generic;
using System.Linq;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Hardware;
using RfidAttendance.Models;

// ---------------------------------------------------------------
// 来源：Forms\ITagConsumer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 由页面窗体实现：表示它有资格接收刷卡事件。
    /// FrmMain 只把刷卡事件转发给「当前显示页」或「正在绑定卡号的窗口」，
    /// 避免多个界面同时对同一张卡做出反应。
    /// </summary>
    public interface ITagConsumer
    {
        void HandleTag(string epc);
    }

    /// <summary>由内嵌页面实现：页面被切换到前台时刷新数据。</summary>
    public interface IPageView
    {
        void OnPageShown();
    }
}

// ---------------------------------------------------------------
// 来源：Services\AttendanceService.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Services
{
    /// <summary>
    /// 考勤业务逻辑：把「一张卡被读到」翻译成「谁、上/下班、几点」并落库。
    /// 界面只调用 HandleCard，不需要自己判断业务规则。
    /// </summary>
    public class AttendanceService
    {
        private readonly EmployeeRepository _employeeRepo = new EmployeeRepository();
        private readonly AttendanceRepository _attendanceRepo = new AttendanceRepository();

        /// <summary>同一员工两次有效打卡之间的最小间隔（秒），防止误刷导致「假下班」。</summary>
        private readonly Dictionary<string, DateTime> _lastPunchTime = new Dictionary<string, DateTime>();
        private readonly object _sync = new object();

        private int _duplicateSeconds;

        public AttendanceService()
        {
            _duplicateSeconds = 30;
            try
            {
                _duplicateSeconds = SettingsStore.GetInt(SettingsStore.KeyDuplicateSeconds, 30);
            }
            catch (Exception ex)
            {
                AppLog.Warn("读取防抖配置失败：" + ex.Message);
            }
        }

        /// <summary>防抖间隔（秒）。</summary>
        public int DuplicateSeconds
        {
            get { return _duplicateSeconds; }
            set
            {
                if (value < 1) value = 1;
                if (value > 600) value = 600;
                _duplicateSeconds = value;
                SettingsStore.SetInt(SettingsStore.KeyDuplicateSeconds, value);
            }
        }

        /// <summary>
        /// 处理一次刷卡。这是整个考勤系统的核心入口。
        /// </summary>
        /// <param name="cardNo">读到的卡号（EPC 十六进制）。</param>
        public PunchResult HandleCard(string cardNo)
        {
            PunchResult result = new PunchResult();
            string normalized = HexUtil.Normalize(cardNo);
            result.CardNo = normalized;

            if (normalized.Length == 0)
            {
                result.Status = PunchStatus.Error;
                result.TitleText = "读卡失败";
                result.Message = "未获取到有效卡号，请重新刷卡。";
                return result;
            }

            try
            {
                Employee employee = _employeeRepo.GetByCardNo(normalized);
                if (employee == null)
                {
                    result.Status = PunchStatus.CardNotBound;
                    result.TitleText = "未登记卡片";
                    result.Message = "该卡还没有绑定员工，请先到「员工管理」里绑定。\r\n卡号：" + normalized;
                    AppLog.Info("未绑定的卡：" + normalized);
                    return result;
                }

                result.Employee = employee;

                if (!employee.IsActive)
                {
                    result.Status = PunchStatus.EmployeeDisabled;
                    result.TitleText = "账号已停用";
                    result.Message = string.Format("{0} 的账号已停用，无法打卡。", employee.Name);
                    return result;
                }

                DateTime now = DateTime.Now;

                // --- 防抖：同一员工短时间内重复刷卡直接忽略 ---
                lock (_sync)
                {
                    DateTime last;
                    if (_lastPunchTime.TryGetValue(employee.EmpNo, out last))
                    {
                        double elapsed = (now - last).TotalSeconds;
                        if (elapsed < _duplicateSeconds)
                        {
                            int wait = (int)Math.Ceiling(_duplicateSeconds - elapsed);
                            result.Status = PunchStatus.Duplicate;
                            result.TitleText = "请勿重复刷卡";
                            result.Message = string.Format("{0}，您刚刚已经打过卡了，请 {1} 秒后再试。",
                                employee.Name, wait);
                            return result;
                        }
                    }
                }

                // --- 判断本次是上班还是下班 ---
                string today = now.ToString("yyyy-MM-dd");
                List<AttendanceRecord> todayRecords = _attendanceRepo.GetByEmployeeAndDate(employee.EmpNo, today);

                bool hasCheckIn = todayRecords.Any(r => r.PunchType == PunchType.CheckIn);
                bool hasCheckOut = todayRecords.Any(r => r.PunchType == PunchType.CheckOut);

                PunchType punchType;
                if (!hasCheckIn)
                {
                    punchType = PunchType.CheckIn;
                }
                else if (!hasCheckOut)
                {
                    punchType = PunchType.CheckOut;
                }
                else
                {
                    result.Status = PunchStatus.Duplicate;
                    result.TitleText = "今日已完成打卡";
                    result.Message = string.Format("{0}，今天上下班都已经打过了。", employee.Name);
                    MarkPunched(employee.EmpNo, now);
                    return result;
                }

                // --- 写入记录 ---
                AttendanceRecord record = new AttendanceRecord();
                record.EmpNo = employee.EmpNo;
                record.EmpName = employee.Name;
                record.Department = employee.Department;
                record.CardNo = normalized;
                record.WorkDate = today;
                record.PunchTime = now;
                record.PunchType = punchType;
                record.DeviceNo = RfidReaderService.Instance.PortName;
                record.Remark = string.Empty;

                _attendanceRepo.Insert(record);
                MarkPunched(employee.EmpNo, now);

                result.Status = PunchStatus.Success;
                result.Record = record;
                result.TitleText = punchType == PunchType.CheckIn ? "上班签到成功" : "下班签退成功";
                result.Message = string.Format("{0}（{1}） {2}",
                    employee.Name, employee.EmpNo, now.ToString("HH:mm:ss"));

                AppLog.Info(string.Format("打卡成功：{0} {1} {2}",
                    employee.EmpNo, employee.Name, result.TitleText));
                return result;
            }
            catch (Exception ex)
            {
                AppLog.Error("处理刷卡时发生异常", ex);
                result.Status = PunchStatus.Error;
                result.TitleText = "处理失败";
                result.Message = ex.Message;
                return result;
            }
        }

        private void MarkPunched(string empNo, DateTime time)
        {
            lock (_sync)
            {
                _lastPunchTime[empNo] = time;
            }
        }

        /// <summary>清空防抖缓存（例如换了读卡器或跨天时）。</summary>
        public void ResetDuplicateGuard()
        {
            lock (_sync)
            {
                _lastPunchTime.Clear();
            }
        }

        /// <summary>今日打卡笔数。</summary>
        public int GetTodayRecordCount()
        {
            return _attendanceRepo.CountToday();
        }

        /// <summary>今日已打卡人数。</summary>
        public int GetTodayPeopleCount()
        {
            return _attendanceRepo.CountTodayPeople();
        }
    }
}
