﻿// 数据实体：员工、考勤记录、打卡结果
using System;

// ---------------------------------------------------------------
// 来源：Models\Employee.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Models
{
    /// <summary>员工信息实体，对应 Employee 表。</summary>
    public class Employee
    {
        public int Id { get; set; }

        /// <summary>工号（唯一）。</summary>
        public string EmpNo { get; set; }

        /// <summary>姓名。</summary>
        public string Name { get; set; }

        /// <summary>部门。</summary>
        public string Department { get; set; }

        /// <summary>职位。</summary>
        public string Position { get; set; }

        /// <summary>绑定的 RFID 卡号（EPC 十六进制串），未绑定为 null。</summary>
        public string CardNo { get; set; }

        /// <summary>联系电话。</summary>
        public string Phone { get; set; }

        public string Remark { get; set; }

        /// <summary>是否启用；停用后刷卡不再记录考勤。</summary>
        public bool IsActive { get; set; }

        public DateTime CreateTime { get; set; }

        public Employee()
        {
            EmpNo = string.Empty;
            Name = string.Empty;
            Department = string.Empty;
            Position = string.Empty;
            Phone = string.Empty;
            Remark = string.Empty;
            IsActive = true;
            CreateTime = DateTime.Now;
        }

        public bool HasCard
        {
            get { return !string.IsNullOrEmpty(CardNo); }
        }

        public string ActiveText
        {
            get { return IsActive ? "启用" : "停用"; }
        }

        public override string ToString()
        {
            return string.Format("{0}（{1}）", Name, EmpNo);
        }
    }
}

// ---------------------------------------------------------------
// 来源：Models\AttendanceRecord.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Models
{
    /// <summary>打卡类型。</summary>
    public enum PunchType
    {
        /// <summary>上班签到。</summary>
        CheckIn = 0,

        /// <summary>下班签退。</summary>
        CheckOut = 1
    }

    /// <summary>单次考勤记录，对应 AttendanceRecord 表。</summary>
    public class AttendanceRecord
    {
        public int Id { get; set; }

        public string EmpNo { get; set; }

        public string EmpName { get; set; }

        public string Department { get; set; }

        public string CardNo { get; set; }

        /// <summary>考勤归属日期，格式 yyyy-MM-dd。</summary>
        public string WorkDate { get; set; }

        /// <summary>刷卡时刻。</summary>
        public DateTime PunchTime { get; set; }

        public PunchType PunchType { get; set; }

        /// <summary>设备编号 / 串口标识。</summary>
        public string DeviceNo { get; set; }

        public string Remark { get; set; }

        public AttendanceRecord()
        {
            EmpNo = string.Empty;
            EmpName = string.Empty;
            Department = string.Empty;
            CardNo = string.Empty;
            WorkDate = DateTime.Now.ToString("yyyy-MM-dd");
            PunchTime = DateTime.Now;
            PunchType = PunchType.CheckIn;
            DeviceNo = string.Empty;
            Remark = string.Empty;
        }

        /// <summary>供界面直接显示的打卡类型文本。</summary>
        public string PunchTypeText
        {
            get { return PunchType == PunchType.CheckIn ? "上班" : "下班"; }
        }

        public string PunchTimeText
        {
            get { return PunchTime.ToString("yyyy-MM-dd HH:mm:ss"); }
        }

        public string PunchTimeOnlyText
        {
            get { return PunchTime.ToString("HH:mm:ss"); }
        }
    }

    /// <summary>按人按天汇总的一行考勤（查询界面用）。</summary>
    public class AttendanceSummary
    {
        public string EmpNo { get; set; }
        public string EmpName { get; set; }
        public string Department { get; set; }
        public string WorkDate { get; set; }
        public DateTime? CheckInTime { get; set; }
        public DateTime? CheckOutTime { get; set; }

        public AttendanceSummary()
        {
            EmpNo = string.Empty;
            EmpName = string.Empty;
            Department = string.Empty;
            WorkDate = string.Empty;
        }

        public string CheckInText
        {
            get { return CheckInTime.HasValue ? CheckInTime.Value.ToString("HH:mm:ss") : "—"; }
        }

        public string CheckOutText
        {
            get { return CheckOutTime.HasValue ? CheckOutTime.Value.ToString("HH:mm:ss") : "—"; }
        }

        /// <summary>在岗时长，下班未打卡时为空。</summary>
        public string DurationText
        {
            get
            {
                if (!CheckInTime.HasValue || !CheckOutTime.HasValue)
                {
                    return "—";
                }
                TimeSpan span = CheckOutTime.Value - CheckInTime.Value;
                if (span.TotalMinutes < 0)
                {
                    return "—";
                }
                return string.Format("{0}小时{1}分", (int)span.TotalHours, span.Minutes);
            }
        }

        /// <summary>考勤状态：正常 / 缺下班卡 / 缺上班卡。</summary>
        public string StatusText
        {
            get
            {
                if (CheckInTime.HasValue && CheckOutTime.HasValue) return "正常";
                if (CheckInTime.HasValue) return "缺下班卡";
                return "缺上班卡";
            }
        }
    }
}

// ---------------------------------------------------------------
// 来源：Models\PunchResult.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Models
{
    /// <summary>一次刷卡的处理结果类型。</summary>
    public enum PunchStatus
    {
        /// <summary>打卡成功。</summary>
        Success = 0,

        /// <summary>重复刷卡，冷却时间内忽略。</summary>
        Duplicate = 1,

        /// <summary>卡号未绑定任何员工。</summary>
        CardNotBound = 2,

        /// <summary>员工已停用。</summary>
        EmployeeDisabled = 3,

        /// <summary>处理过程出错。</summary>
        Error = 4
    }

    /// <summary>
    /// 业务层返回给界面的刷卡结果，界面只负责展示，不再做业务判断。
    /// </summary>
    public class PunchResult
    {
        public PunchStatus Status { get; set; }

        /// <summary>卡号（EPC 十六进制）。</summary>
        public string CardNo { get; set; }

        /// <summary>命中的员工，未绑定时为 null。</summary>
        public Employee Employee { get; set; }

        /// <summary>本次产生的记录，重复刷卡时为 null。</summary>
        public AttendanceRecord Record { get; set; }

        /// <summary>给用户看的一句话说明。</summary>
        public string Message { get; set; }

        /// <summary>头部提示文本，例如「上班签到成功」。</summary>
        public string TitleText { get; set; }

        public PunchResult()
        {
            CardNo = string.Empty;
            Message = string.Empty;
            TitleText = string.Empty;
        }

        public bool IsSuccess
        {
            get { return Status == PunchStatus.Success; }
        }

        /// <summary>当前时间，用于界面展示。</summary>
        public DateTime OccurredAt { get { return Record != null ? Record.PunchTime : DateTime.Now; } }
    }
}
