﻿// 数据访问层：SQLite 建库、员工仓储、考勤仓储、设置存储
using System;
using System.Data;
using System.Data.SQLite;
using System.IO;
using RfidAttendance.Common;
using System.Collections.Generic;
using RfidAttendance.Models;
using System.Text;

// ---------------------------------------------------------------
// 来源：Data\DbHelper.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Data
{
    /// <summary>
    /// SQLite 数据库访问helper：负责连接串、建库建表以及通用查询方法。
    /// 数据库文件放在程序目录的 data\attendance.db。
    /// </summary>
    public static class DbHelper
    {
        private static readonly object InitLock = new object();
        private static bool _initialized;
        private static string _databasePath;

        /// <summary>数据库文件的完整路径。</summary>
        public static string DatabasePath
        {
            get
            {
                if (_databasePath == null)
                {
                    string dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
                    if (!Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }
                    _databasePath = Path.Combine(dir, "attendance.db");
                }
                return _databasePath;
            }
        }

        /// <summary>SQLite 连接字符串。</summary>
        public static string ConnectionString
        {
            get { return string.Format("Data Source={0};Version=3;Pooling=True;", DatabasePath); }
        }

        /// <summary>创建并打开一个连接，调用方负责释放。</summary>
        public static SQLiteConnection OpenConnection()
        {
            SQLiteConnection conn = new SQLiteConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        /// <summary>
        /// 初始化数据库：检测原生库可用性并创建表结构。
        /// 由 Program.Main 在启动时调用一次。
        /// </summary>
        public static void Initialize()
        {
            lock (InitLock)
            {
                if (_initialized)
                {
                    return;
                }

                try
                {
                    using (SQLiteConnection conn = OpenConnection())
                    {
                        Execute(conn, SqlCreateEmployee);
                        Execute(conn, SqlCreateAttendance);
                        Execute(conn, SqlCreateSetting);
                        Execute(conn, "CREATE INDEX IF NOT EXISTS IX_Employee_CardNo ON Employee(CardNo)");
                        Execute(conn, "CREATE INDEX IF NOT EXISTS IX_Attendance_WorkDate ON AttendanceRecord(WorkDate)");
                        Execute(conn, "CREATE INDEX IF NOT EXISTS IX_Attendance_EmpNo ON AttendanceRecord(EmpNo)");
                    }
                }
                catch (DllNotFoundException ex)
                {
                    AppLog.Error("SQLite 原生库加载失败", ex);
                    throw new InvalidOperationException(
                        "未能加载 SQLite 原生库（SQLite.Interop.dll）。\r\n" +
                        "请确认程序目录下存在 x86\\SQLite.Interop.dll，且程序以 x86 方式编译。", ex);
                }
                catch (BadImageFormatException ex)
                {
                    AppLog.Error("SQLite 原生库位数不匹配", ex);
                    throw new InvalidOperationException(
                        "SQLite 原生库与程序位数不匹配。\r\n" +
                        "请把解决方案平台的「平台目标」设为 x86（读卡器 SDK 只提供 32 位库）。", ex);
                }

                _initialized = true;
                AppLog.Info("数据库初始化完成：" + DatabasePath);
            }
        }

        /// <summary>执行一条非查询语句。</summary>
        public static int ExecuteNonQuery(string sql, params SQLiteParameter[] parameters)
        {
            using (SQLiteConnection conn = OpenConnection())
            {
                return ExecuteNonQuery(conn, sql, parameters);
            }
        }

        internal static int ExecuteNonQuery(SQLiteConnection conn, string sql,
            params SQLiteParameter[] parameters)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>执行标量查询。</summary>
        public static object ExecuteScalar(string sql, params SQLiteParameter[] parameters)
        {
            using (SQLiteConnection conn = OpenConnection())
            using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                return cmd.ExecuteScalar();
            }
        }

        /// <summary>查询并返回 DataTable。</summary>
        public static DataTable Query(string sql, params SQLiteParameter[] parameters)
        {
            DataTable table = new DataTable();
            using (SQLiteConnection conn = OpenConnection())
            using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        /// <summary>快捷构造参数。</summary>
        public static SQLiteParameter P(string name, object value)
        {
            return new SQLiteParameter(name, value == null ? DBNull.Value : value);
        }

        private static void Execute(SQLiteConnection conn, string sql)
        {
            using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private const string SqlCreateEmployee =
            "CREATE TABLE IF NOT EXISTS Employee (" +
            "  Id         INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  EmpNo      TEXT    NOT NULL," +
            "  Name       TEXT    NOT NULL," +
            "  Department TEXT    DEFAULT ''," +
            "  Position   TEXT    DEFAULT ''," +
            "  CardNo     TEXT    DEFAULT ''," +
            "  Phone      TEXT    DEFAULT ''," +
            "  Remark     TEXT    DEFAULT ''," +
            "  IsActive   INTEGER NOT NULL DEFAULT 1," +
            "  CreateTime TEXT    NOT NULL" +
            ")";

        private const string SqlCreateAttendance =
            "CREATE TABLE IF NOT EXISTS AttendanceRecord (" +
            "  Id        INTEGER PRIMARY KEY AUTOINCREMENT," +
            "  EmpNo     TEXT    NOT NULL," +
            "  EmpName   TEXT    NOT NULL," +
            "  Department TEXT   DEFAULT ''," +
            "  CardNo    TEXT    DEFAULT ''," +
            "  WorkDate  TEXT    NOT NULL," +
            "  PunchTime TEXT    NOT NULL," +
            "  PunchType INTEGER NOT NULL," +
            "  DeviceNo  TEXT    DEFAULT ''," +
            "  Remark    TEXT    DEFAULT ''" +
            ")";

        private const string SqlCreateSetting =
            "CREATE TABLE IF NOT EXISTS Setting (" +
            "  Key   TEXT PRIMARY KEY," +
            "  Value TEXT" +
            ")";
    }
}

// ---------------------------------------------------------------
// 来源：Data\EmployeeRepository.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Data
{
    /// <summary>员工信息的数据访问层。</summary>
    public class EmployeeRepository
    {
        private const string SelectColumns =
            "Id, EmpNo, Name, Department, Position, CardNo, Phone, Remark, IsActive, CreateTime";

        /// <summary>查询全部员工，按工号排序。</summary>
        public List<Employee> GetAll()
        {
            List<Employee> list = new List<Employee>();
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM Employee ORDER BY EmpNo");
            foreach (DataRow row in table.Rows)
            {
                list.Add(Map(row));
            }
            return list;
        }

        /// <summary>按姓名 / 工号 / 部门模糊搜索。</summary>
        public List<Employee> Search(string keyword)
        {
            if (string.IsNullOrEmpty(keyword))
            {
                return GetAll();
            }

            List<Employee> list = new List<Employee>();
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM Employee" +
                " WHERE EmpNo LIKE @kw OR Name LIKE @kw OR Department LIKE @kw" +
                " ORDER BY EmpNo",
                DbHelper.P("@kw", "%" + keyword.Trim() + "%"));
            foreach (DataRow row in table.Rows)
            {
                list.Add(Map(row));
            }
            return list;
        }

        public Employee GetById(int id)
        {
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM Employee WHERE Id = @id",
                DbHelper.P("@id", id));
            return table.Rows.Count > 0 ? Map(table.Rows[0]) : null;
        }

        public Employee GetByEmpNo(string empNo)
        {
            if (string.IsNullOrEmpty(empNo))
            {
                return null;
            }
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM Employee WHERE EmpNo = @no",
                DbHelper.P("@no", empNo.Trim()));
            return table.Rows.Count > 0 ? Map(table.Rows[0]) : null;
        }

        /// <summary>按卡号查员工，这是刷卡考勤最核心的查询。</summary>
        public Employee GetByCardNo(string cardNo)
        {
            string normalized = HexUtil.Normalize(cardNo);
            if (normalized.Length == 0)
            {
                return null;
            }
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM Employee WHERE UPPER(CardNo) = @card",
                DbHelper.P("@card", normalized));
            return table.Rows.Count > 0 ? Map(table.Rows[0]) : null;
        }

        /// <summary>判断工号是否已被占用（excludeId 用于编辑时排除自身）。</summary>
        public bool EmpNoExists(string empNo, int excludeId)
        {
            object count = DbHelper.ExecuteScalar(
                "SELECT COUNT(1) FROM Employee WHERE EmpNo = @no AND Id <> @id",
                DbHelper.P("@no", empNo.Trim()),
                DbHelper.P("@id", excludeId));
            return Convert.ToInt32(count) > 0;
        }

        /// <summary>判断卡号是否已绑定给别的员工。</summary>
        public bool CardNoExists(string cardNo, int excludeId)
        {
            string normalized = HexUtil.Normalize(cardNo);
            if (normalized.Length == 0)
            {
                return false;
            }
            object count = DbHelper.ExecuteScalar(
                "SELECT COUNT(1) FROM Employee WHERE UPPER(CardNo) = @card AND Id <> @id",
                DbHelper.P("@card", normalized),
                DbHelper.P("@id", excludeId));
            return Convert.ToInt32(count) > 0;
        }

        /// <summary>新增员工，返回新记录的主键。</summary>
        public int Insert(Employee employee)
        {
            const string sql =
                "INSERT INTO Employee (EmpNo, Name, Department, Position, CardNo, Phone, Remark, IsActive, CreateTime)" +
                " VALUES (@no, @name, @dept, @pos, @card, @phone, @remark, @active, @create);" +
                " SELECT last_insert_rowid();";

            object id = DbHelper.ExecuteScalar(sql,
                DbHelper.P("@no", employee.EmpNo.Trim()),
                DbHelper.P("@name", employee.Name.Trim()),
                DbHelper.P("@dept", Safe(employee.Department)),
                DbHelper.P("@pos", Safe(employee.Position)),
                DbHelper.P("@card", HexUtil.Normalize(employee.CardNo)),
                DbHelper.P("@phone", Safe(employee.Phone)),
                DbHelper.P("@remark", Safe(employee.Remark)),
                DbHelper.P("@active", employee.IsActive ? 1 : 0),
                DbHelper.P("@create", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));

            employee.Id = Convert.ToInt32(id);
            return employee.Id;
        }

        /// <summary>更新员工资料。</summary>
        public void Update(Employee employee)
        {
            const string sql =
                "UPDATE Employee SET EmpNo = @no, Name = @name, Department = @dept, Position = @pos," +
                " CardNo = @card, Phone = @phone, Remark = @remark, IsActive = @active WHERE Id = @id";

            DbHelper.ExecuteNonQuery(sql,
                DbHelper.P("@no", employee.EmpNo.Trim()),
                DbHelper.P("@name", employee.Name.Trim()),
                DbHelper.P("@dept", Safe(employee.Department)),
                DbHelper.P("@pos", Safe(employee.Position)),
                DbHelper.P("@card", HexUtil.Normalize(employee.CardNo)),
                DbHelper.P("@phone", Safe(employee.Phone)),
                DbHelper.P("@remark", Safe(employee.Remark)),
                DbHelper.P("@active", employee.IsActive ? 1 : 0),
                DbHelper.P("@id", employee.Id));
        }

        /// <summary>只更新卡号绑定关系。</summary>
        public void UpdateCardNo(int employeeId, string cardNo)
        {
            DbHelper.ExecuteNonQuery(
                "UPDATE Employee SET CardNo = @card WHERE Id = @id",
                DbHelper.P("@card", HexUtil.Normalize(cardNo)),
                DbHelper.P("@id", employeeId));
        }

        /// <summary>按主键删除员工（考勤记录保留，便于追溯）。</summary>
        public void Delete(int id)
        {
            DbHelper.ExecuteNonQuery("DELETE FROM Employee WHERE Id = @id", DbHelper.P("@id", id));
        }

        public int Count()
        {
            return Convert.ToInt32(DbHelper.ExecuteScalar("SELECT COUNT(1) FROM Employee"));
        }

        public int CountBound()
        {
            return Convert.ToInt32(DbHelper.ExecuteScalar(
                "SELECT COUNT(1) FROM Employee WHERE CardNo IS NOT NULL AND CardNo <> ''"));
        }

        private static string Safe(string value)
        {
            return value == null ? string.Empty : value.Trim();
        }

        private static Employee Map(DataRow row)
        {
            Employee e = new Employee();
            e.Id = Convert.ToInt32(row["Id"]);
            e.EmpNo = AsString(row["EmpNo"]);
            e.Name = AsString(row["Name"]);
            e.Department = AsString(row["Department"]);
            e.Position = AsString(row["Position"]);
            e.CardNo = AsString(row["CardNo"]);
            e.Phone = AsString(row["Phone"]);
            e.Remark = AsString(row["Remark"]);
            e.IsActive = Convert.ToInt32(row["IsActive"]) != 0;

            DateTime created;
            if (DateTime.TryParse(AsString(row["CreateTime"]), out created))
            {
                e.CreateTime = created;
            }
            return e;
        }

        private static string AsString(object value)
        {
            return value == null || value == DBNull.Value ? string.Empty : value.ToString();
        }
    }
}

// ---------------------------------------------------------------
// 来源：Data\AttendanceRepository.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Data
{
    /// <summary>考勤记录的数据访问层。</summary>
    public class AttendanceRepository
    {
        private const string SelectColumns =
            "Id, EmpNo, EmpName, Department, CardNo, WorkDate, PunchTime, PunchType, DeviceNo, Remark";

        private const string TimeFormat = "yyyy-MM-dd HH:mm:ss";
        private const string DateFormat = "yyyy-MM-dd";

        /// <summary>写入一条考勤记录，返回自增主键。</summary>
        public int Insert(AttendanceRecord record)
        {
            const string sql =
                "INSERT INTO AttendanceRecord" +
                " (EmpNo, EmpName, Department, CardNo, WorkDate, PunchTime, PunchType, DeviceNo, Remark)" +
                " VALUES (@no, @name, @dept, @card, @date, @time, @type, @device, @remark);" +
                " SELECT last_insert_rowid();";

            object id = DbHelper.ExecuteScalar(sql,
                DbHelper.P("@no", record.EmpNo),
                DbHelper.P("@name", record.EmpName),
                DbHelper.P("@dept", record.Department),
                DbHelper.P("@card", record.CardNo),
                DbHelper.P("@date", record.WorkDate),
                DbHelper.P("@time", record.PunchTime.ToString(TimeFormat)),
                DbHelper.P("@type", (int)record.PunchType),
                DbHelper.P("@device", record.DeviceNo),
                DbHelper.P("@remark", record.Remark));

            record.Id = Convert.ToInt32(id);
            return record.Id;
        }

        /// <summary>取某员工某天的全部打卡记录（按时间正序）。</summary>
        public List<AttendanceRecord> GetByEmployeeAndDate(string empNo, string workDate)
        {
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM AttendanceRecord" +
                " WHERE EmpNo = @no AND WorkDate = @date ORDER BY PunchTime",
                DbHelper.P("@no", empNo),
                DbHelper.P("@date", workDate));

            List<AttendanceRecord> list = new List<AttendanceRecord>();
            foreach (DataRow row in table.Rows)
            {
                list.Add(Map(row));
            }
            return list;
        }

        /// <summary>取某员工最近一次打卡（用于防抖判断）。</summary>
        public AttendanceRecord GetLatestByEmployee(string empNo)
        {
            DataTable table = DbHelper.Query(
                "SELECT " + SelectColumns + " FROM AttendanceRecord" +
                " WHERE EmpNo = @no ORDER BY PunchTime DESC, Id DESC LIMIT 1",
                DbHelper.P("@no", empNo));

            return table.Rows.Count > 0 ? Map(table.Rows[0]) : null;
        }

        /// <summary>按日期区间（含端点）查询明细，可选按工号/姓名过滤。</summary>
        public List<AttendanceRecord> Query(string dateFrom, string dateTo, string keyword)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("SELECT ").Append(SelectColumns).Append(" FROM AttendanceRecord WHERE 1 = 1");

            List<System.Data.SQLite.SQLiteParameter> ps = new List<System.Data.SQLite.SQLiteParameter>();
            if (!string.IsNullOrEmpty(dateFrom))
            {
                sql.Append(" AND WorkDate >= @from");
                ps.Add(DbHelper.P("@from", dateFrom));
            }
            if (!string.IsNullOrEmpty(dateTo))
            {
                sql.Append(" AND WorkDate <= @to");
                ps.Add(DbHelper.P("@to", dateTo));
            }
            if (!string.IsNullOrEmpty(keyword))
            {
                sql.Append(" AND (EmpNo LIKE @kw OR EmpName LIKE @kw)");
                ps.Add(DbHelper.P("@kw", "%" + keyword.Trim() + "%"));
            }
            sql.Append(" ORDER BY WorkDate DESC, PunchTime DESC, Id DESC");

            DataTable table = DbHelper.Query(sql.ToString(), ps.ToArray());
            List<AttendanceRecord> list = new List<AttendanceRecord>();
            foreach (DataRow row in table.Rows)
            {
                list.Add(Map(row));
            }
            return list;
        }

        /// <summary>
        /// 按人 + 天汇总，返回上班时间 / 下班时间 / 在岗时长。
        /// 用 SQL 的 CASE WHEN 聚合，避免在内存里做分组。
        /// </summary>
        public List<AttendanceSummary> QuerySummary(string dateFrom, string dateTo, string keyword)
        {
            StringBuilder sql = new StringBuilder();
            sql.Append("SELECT EmpNo, EmpName, MAX(Department) AS Department, WorkDate,");
            sql.Append(" MIN(CASE WHEN PunchType = 0 THEN PunchTime END) AS CheckInTime,");
            sql.Append(" MAX(CASE WHEN PunchType = 1 THEN PunchTime END) AS CheckOutTime");
            sql.Append(" FROM AttendanceRecord WHERE 1 = 1");

            List<System.Data.SQLite.SQLiteParameter> ps = new List<System.Data.SQLite.SQLiteParameter>();
            if (!string.IsNullOrEmpty(dateFrom))
            {
                sql.Append(" AND WorkDate >= @from");
                ps.Add(DbHelper.P("@from", dateFrom));
            }
            if (!string.IsNullOrEmpty(dateTo))
            {
                sql.Append(" AND WorkDate <= @to");
                ps.Add(DbHelper.P("@to", dateTo));
            }
            if (!string.IsNullOrEmpty(keyword))
            {
                sql.Append(" AND (EmpNo LIKE @kw OR EmpName LIKE @kw)");
                ps.Add(DbHelper.P("@kw", "%" + keyword.Trim() + "%"));
            }
            sql.Append(" GROUP BY EmpNo, WorkDate ORDER BY WorkDate DESC, EmpNo");

            DataTable table = DbHelper.Query(sql.ToString(), ps.ToArray());
            List<AttendanceSummary> list = new List<AttendanceSummary>();
            foreach (DataRow row in table.Rows)
            {
                AttendanceSummary s = new AttendanceSummary();
                s.EmpNo = AsString(row["EmpNo"]);
                s.EmpName = AsString(row["EmpName"]);
                s.Department = AsString(row["Department"]);
                s.WorkDate = AsString(row["WorkDate"]);
                s.CheckInTime = ParseTime(row["CheckInTime"]);
                s.CheckOutTime = ParseTime(row["CheckOutTime"]);
                list.Add(s);
            }
            return list;
        }

        /// <summary>按主键删除若干条记录。</summary>
        public int DeleteByIds(IEnumerable<int> ids)
        {
            int affected = 0;
            using (System.Data.SQLite.SQLiteConnection conn = DbHelper.OpenConnection())
            using (System.Data.SQLite.SQLiteTransaction tx = conn.BeginTransaction())
            {
                foreach (int id in ids)
                {
                    affected += DbHelper.ExecuteNonQuery(conn, "DELETE FROM AttendanceRecord WHERE Id = @id",
                        DbHelper.P("@id", id));
                }
                tx.Commit();
            }
            return affected;
        }

        public int CountToday()
        {
            string today = DateTime.Now.ToString(DateFormat);
            return Convert.ToInt32(DbHelper.ExecuteScalar(
                "SELECT COUNT(1) FROM AttendanceRecord WHERE WorkDate = @date",
                DbHelper.P("@date", today)));
        }

        /// <summary>今日已打卡人数（去重）。</summary>
        public int CountTodayPeople()
        {
            string today = DateTime.Now.ToString(DateFormat);
            return Convert.ToInt32(DbHelper.ExecuteScalar(
                "SELECT COUNT(DISTINCT EmpNo) FROM AttendanceRecord WHERE WorkDate = @date",
                DbHelper.P("@date", today)));
        }

        private static AttendanceRecord Map(DataRow row)
        {
            AttendanceRecord r = new AttendanceRecord();
            r.Id = Convert.ToInt32(row["Id"]);
            r.EmpNo = AsString(row["EmpNo"]);
            r.EmpName = AsString(row["EmpName"]);
            r.Department = AsString(row["Department"]);
            r.CardNo = AsString(row["CardNo"]);
            r.WorkDate = AsString(row["WorkDate"]);
            r.PunchTime = ParseTime(row["PunchTime"]) ?? DateTime.Now;
            r.PunchType = Convert.ToInt32(row["PunchType"]) == 0 ? PunchType.CheckIn : PunchType.CheckOut;
            r.DeviceNo = AsString(row["DeviceNo"]);
            r.Remark = AsString(row["Remark"]);
            return r;
        }

        private static DateTime? ParseTime(object value)
        {
            if (value == null || value == DBNull.Value)
            {
                return null;
            }
            DateTime result;
            if (DateTime.TryParse(value.ToString(), out result))
            {
                return result;
            }
            return null;
        }

        private static string AsString(object value)
        {
            return value == null || value == DBNull.Value ? string.Empty : value.ToString();
        }
    }
}

// ---------------------------------------------------------------
// 来源：Data\SettingsStore.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Data
{
    /// <summary>
    /// 轻量配置存储：把界面上的设置（串口、波特率、功率、防抖时间）存进 SQLite 的 Setting 表，
    /// 这样不需要额外引用 System.Configuration，也便于随程序一起搬走。
    /// </summary>
    public static class SettingsStore
    {
        public const string KeyPort = "Reader.Port";
        public const string KeyBaudIndex = "Reader.BaudIndex";
        public const string KeyPowerDbm = "Reader.PowerDbm";
        public const string KeyDuplicateSeconds = "Attendance.DuplicateSeconds";

        public static string Get(string key, string defaultValue)
        {
            try
            {
                object value = DbHelper.ExecuteScalar(
                    "SELECT Value FROM Setting WHERE Key = @k", DbHelper.P("@k", key));
                if (value == null || value == DBNull.Value)
                {
                    return defaultValue;
                }
                return value.ToString();
            }
            catch (Exception)
            {
                return defaultValue;
            }
        }

        public static int GetInt(string key, int defaultValue)
        {
            string text = Get(key, null);
            int result;
            if (!string.IsNullOrEmpty(text) && int.TryParse(text, out result))
            {
                return result;
            }
            return defaultValue;
        }

        public static void Set(string key, string value)
        {
            DbHelper.ExecuteNonQuery(
                "INSERT OR REPLACE INTO Setting (Key, Value) VALUES (@k, @v)",
                DbHelper.P("@k", key),
                DbHelper.P("@v", value == null ? string.Empty : value));
        }

        public static void SetInt(string key, int value)
        {
            Set(key, value.ToString());
        }
    }
}
