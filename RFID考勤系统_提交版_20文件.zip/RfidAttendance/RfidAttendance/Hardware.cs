﻿// 硬件层：读卡器串口通讯、盘存线程、读卡事件
using System;
using System.Collections.Generic;
using System.Threading;
using RfidAttendance.Common;
using ReaderB;

// ---------------------------------------------------------------
// 来源：Hardware\TagReadEventArgs.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Hardware
{
    /// <summary>读到一张 RFID 卡时触发。</summary>
    public class TagReadEventArgs : EventArgs
    {
        /// <summary>盘存读到的 EPC 十六进制字符串（大写无分隔）。同一批卡可能重复。</summary>
        public string Epc { get; private set; }

        /// <summary>
        /// 标签的 TID（芯片出厂固化的唯一编号，物理上不可修改）。
        /// 读取失败时为空字符串。
        /// </summary>
        public string Tid { get; private set; }

        /// <summary>
        /// 用来当卡号的编号：优先取 TID，读不到时退回 EPC。
        /// 界面和数据库一律用这个字段，不直接用 Epc。
        /// </summary>
        public string CardNo { get; private set; }

        /// <summary>读取时刻。</summary>
        public DateTime Timestamp { get; private set; }

        public TagReadEventArgs(string epc, string tid)
        {
            Epc = epc;
            Tid = tid == null ? string.Empty : tid;
            CardNo = string.IsNullOrEmpty(Tid) ? epc : Tid;
            Timestamp = DateTime.Now;
        }
    }

    /// <summary>读卡器连接状态变化时触发。</summary>
    public class ReaderStatusEventArgs : EventArgs
    {
        /// <summary>是否已连接。</summary>
        public bool Connected { get; private set; }

        /// <summary>状态描述，直接显示在界面上。</summary>
        public string Message { get; private set; }

        /// <summary>是否为错误状态。</summary>
        public bool IsError { get; private set; }

        public ReaderStatusEventArgs(bool connected, string message, bool isError)
        {
            Connected = connected;
            Message = message;
            IsError = isError;
        }
    }
}

// ---------------------------------------------------------------
// 来源：Hardware\RfidReaderService.cs
// ---------------------------------------------------------------
// 读卡器 SDK：UHFReader18CSharp.dll（恺乐 KL 系列 / UHFReader18 模块）
namespace RfidAttendance.Hardware
{
    /// <summary>
    /// KL9007U（UHFReader18）读卡器服务。
    ///
    /// 说明：
    /// 1. SDK 的 StaticClassReaderB 内部维护全局串口状态，因此本服务做成单例；
    /// 2. 盘存（Inventory_G2）在后台线程按固定间隔轮询，读到卡通过 TagRead 事件抛出；
    /// 3. 同一张卡在 ReportIntervalMs 内只上报一次，避免轮询造成的事件风暴。
    ///
    /// SDK 原生库 Basic.dll 只有 32 位版本，故整个程序必须编译为 x86。
    /// </summary>
    public sealed class RfidReaderService : IDisposable
    {
        private static readonly RfidReaderService _instance = new RfidReaderService();

        /// <summary>全局唯一实例。</summary>
        public static RfidReaderService Instance
        {
            get { return _instance; }
        }

        /// <summary>读到卡时触发（在后台线程，界面需自行 Invoke）。</summary>
        public event EventHandler<TagReadEventArgs> TagRead;

        /// <summary>连接状态变化时触发。</summary>
        public event EventHandler<ReaderStatusEventArgs> StatusChanged;

        /// <summary>界面上可选的波特率文本，与 SDK 的波特率索引一一对应。</summary>
        public static readonly string[] BaudRateTexts = new string[]
        {
            "9600bps", "19200bps", "38400bps", "57600bps", "115200bps"
        };

        private readonly object _sync = new object();
        private readonly Dictionary<string, DateTime> _recentTags = new Dictionary<string, DateTime>();

        private Thread _worker;
        private volatile bool _running;

        private int _comIndex = -1;
        private byte _comAdr = 0xFF;
        private byte _baud = 5;
        private string _portName = string.Empty;
        private string _readerType = string.Empty;
        private byte _powerDbm;
        private DateTime _lastCleanup = DateTime.Now;

        // 自动重连用的「上次成功连接参数」
        private string _recoverPortName = string.Empty;
        private int _recoverBaudUiIndex = 3;

        /// <summary>同一张卡的重复上报间隔（毫秒）。</summary>
        public int ReportIntervalMs { get; set; }

        /// <summary>轮询间隔（毫秒）。</summary>
        public int PollIntervalMs { get; set; }

        /// <summary>
        /// 是否把标签的 TID 当作卡号。默认 true。
        /// TID 是芯片出厂固化的唯一编号，物理上无法修改；
        /// 而同一批卡可能被写成相同的 EPC（且被锁死），此时只有 TID 能区分它们。
        /// TID 读取失败时自动退回 EPC。
        /// </summary>
        public bool UseTidAsCardNo { get; set; }

        private RfidReaderService()
        {
            ReportIntervalMs = 2500;
            PollIntervalMs = 150;
            UseTidAsCardNo = true;
        }

        /// <summary>当前是否已打开串口。</summary>
        public bool IsOpen
        {
            get { return _comIndex != -1; }
        }

        /// <summary>当前串口名，例如 COM3；未打开时为空。</summary>
        public string PortName
        {
            get { return _portName; }
        }

        /// <summary>读卡器型号信息，打开成功后可用。</summary>
        public string ReaderType
        {
            get { return _readerType; }
        }

        /// <summary>当前波特率文本。</summary>
        public string BaudText
        {
            get
            {
                int index = _baud > 2 ? _baud - 2 : _baud;
                if (index >= 0 && index < BaudRateTexts.Length)
                {
                    return BaudRateTexts[index];
                }
                return _baud.ToString();
            }
        }

        #region 打开 / 关闭

        /// <summary>
        /// 打开读卡器。
        /// </summary>
        /// <param name="portName">串口名，如 "COM3"；传空字符串表示自动搜索。</param>
        /// <param name="baudUiIndex">界面上的波特率下标（0=9600 … 4=115200）。</param>
        /// <param name="error">失败原因。</param>
        public bool Open(string portName, int baudUiIndex, out string error)
        {
            lock (_sync)
            {
                error = string.Empty;

                if (IsOpen)
                {
                    error = "读卡器已处于打开状态。";
                    return false;
                }

                PreviewBaudIndex = baudUiIndex;
                byte baud = ToSdkBaud(baudUiIndex);
                int port = 0;
                int comIndex = -1;
                byte comAdr = 0xFF;
                int result;

                try
                {
                    if (string.IsNullOrEmpty(portName))
                    {
                        // 自动搜索：SDK 会遍历所有串口与波特率
                        result = StaticClassReaderB.AutoOpenComPort(ref port, ref comAdr, baud, ref comIndex);
                    }
                    else
                    {
                        int portNumber = ParsePortNumber(portName);
                        if (portNumber <= 0)
                        {
                            error = "串口名格式不正确：" + portName;
                            return false;
                        }
                        result = OpenSpecificPort(portNumber, ref comAdr, ref comIndex);
                    }
                }
                catch (DllNotFoundException ex)
                {
                    AppLog.Error("读卡器原生库加载失败", ex);
                    error = "未能加载读卡器通讯库（Basic.dll）。\r\n" +
                            "请确认程序目录下存在 Basic.dll，且程序以 x86 方式编译。";
                    RaiseStatus(false, error, true);
                    return false;
                }
                catch (BadImageFormatException ex)
                {
                    AppLog.Error("读卡器通讯库位数不匹配", ex);
                    error = "读卡器通讯库位数与程序不匹配。\r\n请把平台目标设为 x86 后重新编译。";
                    RaiseStatus(false, error, true);
                    return false;
                }
                catch (Exception ex)
                {
                    AppLog.Error("打开读卡器异常", ex);
                    error = "打开读卡器时发生异常：" + ex.Message;
                    RaiseStatus(false, error, true);
                    return false;
                }

                if (result != 0 || comIndex == -1)
                {
                    error = string.IsNullOrEmpty(portName)
                        ? "未能找到读卡器。请检查 USB 线、CP210x 驱动以及读写器电源。"
                        : string.Format("打开 {0} 失败（返回码 {1}）。请确认串口未被其他程序占用。", portName, result);
                    AppLog.Warn("打开读卡器失败：" + error);
                    RaiseStatus(false, error, true);
                    return false;
                }

                _comIndex = comIndex;
                _comAdr = comAdr;
                _baud = baud;
                _portName = "COM" + comIndex;

                string readerInfo;
                if (!TryReadReaderInfo(ref comAdr, comIndex, out readerInfo))
                {
                    // 串口能打开但读卡器不答应：关掉它，别让界面显示成「已连接」
                    try
                    {
                        StaticClassReaderB.CloseSpecComPort(comIndex);
                    }
                    catch (Exception closeEx)
                    {
                        AppLog.Warn("关闭无应答的串口失败：" + closeEx.Message);
                    }

                    _comIndex = -1;
                    _portName = string.Empty;

                    error = string.IsNullOrEmpty(portName)
                        ? "串口打开了，但读卡器没有应答。\r\n\r\n请检查：\r\n" +
                          "1. USB 线是否插紧；\r\n" +
                          "2. 读写器电源是否接通；\r\n" +
                          "3. CP210x 驱动是否安装成功（设备管理器里能看到 COM 口）。"
                        : string.Format("{0} 打开了，但读卡器没有应答。\r\n\r\n" +
                          "请确认选对了串口，并且没有其他程序正在占用它。", portName);

                    AppLog.Warn("读卡器验证失败：" + error);
                    RaiseStatus(false, error, true);
                    return false;
                }

                _readerType = readerInfo;
                _recoverPortName = string.IsNullOrEmpty(portName) ? _portName : portName;
                _recoverBaudUiIndex = baudUiIndex;

                AppLog.Info(string.Format("读卡器已打开：{0}，波特率 {1}，{2}",
                    _portName, BaudText, _readerType));

                RaiseStatus(true, string.Format("已连接 {0}（{1}）", _portName, BaudText), false);
                return true;
            }
        }

        /// <summary>关闭读卡器并停止盘存线程。</summary>
        public void Close()
        {
            StopInventory();

            lock (_sync)
            {
                if (_comIndex != -1)
                {
                    try
                    {
                        StaticClassReaderB.CloseSpecComPort(_comIndex);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Error("关闭读卡器异常", ex);
                    }
                    AppLog.Info("读卡器已关闭：" + _portName);
                    _comIndex = -1;
                    _portName = string.Empty;
                    _readerType = string.Empty;
                }
            }

            RaiseStatus(false, "读卡器未连接", false);
        }

        /// <summary>遍历波特率尝试打开指定串口，与厂家演示程序的做法保持一致。</summary>
        private int OpenSpecificPort(int portNumber, ref byte comAdr, ref int comIndex)
        {
            int result = 30;
            for (int i = 6; i >= 0; i--)
            {
                if (i == 3)
                {
                    // baud = 3 是保留值，厂家演示程序同样跳过
                    continue;
                }
                byte b = (byte)i;
                result = StaticClassReaderB.OpenComPort(portNumber, ref comAdr, b, ref comIndex);
                if (result == 0x35)
                {
                    // 串口已被占用
                    return result;
                }
                if (result == 0)
                {
                    _baud = b;
                    return 0;
                }
            }
            return result;
        }

        /// <summary>把界面波特率下标换算成 SDK 的波特率索引。</summary>
        private static byte ToSdkBaud(int baudUiIndex)
        {
            if (baudUiIndex < 0)
            {
                baudUiIndex = 0;
            }
            if (baudUiIndex > 4)
            {
                baudUiIndex = 4;
            }
            byte b = (byte)baudUiIndex;
            if (b > 2)
            {
                b = (byte)(b + 2);
            }
            return b;
        }

        /// <summary>界面选中的波特率下标（打开前用于显示）。</summary>
        public int PreviewBaudIndex { get; private set; }

        private static int ParsePortNumber(string portName)
        {
            if (string.IsNullOrEmpty(portName))
            {
                return 0;
            }
            string digits = portName.Trim().ToUpperInvariant().Replace("COM", string.Empty);
            int number;
            if (int.TryParse(digits, out number))
            {
                return number;
            }
            return 0;
        }

        /// <summary>
        /// 读取读写器信息，用于确认串口对面确实是一台读卡器。
        /// 打开串口本身成功并不代表设备在线——蓝牙虚拟串口之类也会打开成功，
        /// 所以厂家演示程序同样是「打开后立刻读一次信息」来判定。
        /// </summary>
        private bool TryReadReaderInfo(ref byte comAdr, int comIndex, out string info)
        {
            info = string.Empty;

            for (int attempt = 0; attempt < 3; attempt++)
            {
                try
                {
                    byte[] versionInfo = new byte[2];
                    byte[] trType = new byte[2];
                    byte readerType = 0;
                    byte dmaxfre = 0;
                    byte dminfre = 0;
                    byte powerDbm = 0;
                    byte scanTime = 0;

                    int result = StaticClassReaderB.GetReaderInformation(ref comAdr, versionInfo,
                        ref readerType, trType, ref dmaxfre, ref dminfre, ref powerDbm, ref scanTime, comIndex);

                    if (result == 0)
                    {
                        _powerDbm = powerDbm;
                        info = string.Format("UHFReader18 V{0}.{1}，功率 {2}dBm",
                            versionInfo[0], versionInfo[1], powerDbm);
                        return true;
                    }

                    AppLog.Warn(string.Format("读取读写器信息返回码 {0}（第 {1} 次尝试）", result, attempt + 1));
                }
                catch (Exception ex)
                {
                    AppLog.Warn("读取读写器信息异常：" + ex.Message);
                }

                // 刚打开串口时设备可能还没准备好，稍等一下再试
                System.Threading.Thread.Sleep(120);
            }

            return false;
        }

        /// <summary>当前发射功率（dBm）。</summary>
        public byte PowerDbm
        {
            get { return _powerDbm; }
        }

        /// <summary>设置发射功率，成功返回 true。</summary>
        public bool SetPowerDbm(byte power)
        {
            if (!IsOpen)
            {
                return false;
            }
            lock (_sync)
            {
                try
                {
                    int result = StaticClassReaderB.SetPowerDbm(ref _comAdr, power, _comIndex);
                    if (result == 0)
                    {
                        _powerDbm = power;
                        AppLog.Info("设置功率为 " + power + " dBm");
                        return true;
                    }
                    AppLog.Warn("设置功率失败，返回码 " + result);
                    return false;
                }
                catch (Exception ex)
                {
                    AppLog.Error("设置功率异常", ex);
                    return false;
                }
            }
        }

        #endregion

        #region 盘存线程

        /// <summary>开始连续盘存。</summary>
        public void StartInventory()
        {
            if (!IsOpen)
            {
                return;
            }

            Thread worker = _worker;
            if (worker != null && worker.IsAlive && _running)
            {
                return;
            }

            // 旧线程正在收尾（可能卡在重连的打开操作里）：等它退出再起，避免两个线程同抢串口
            if (worker != null && worker.IsAlive)
            {
                _running = false;
                worker.Join(2000);
            }

            _running = true;
            _worker = new Thread(InventoryLoop);
            _worker.IsBackground = true;
            _worker.Name = "RfidInventory";
            _worker.Start();
        }

        /// <summary>停止盘存。</summary>
        public void StopInventory()
        {
            _running = false;
            Thread worker = _worker;
            _worker = null;
            if (worker != null && worker.IsAlive)
            {
                // 盘存命令最长约 100ms，给足时间自然退出，不使用 Thread.Abort
                worker.Join(1500);
            }
        }

        /// <summary>是否正在盘存。</summary>
        public bool IsInventoryRunning
        {
            get { return _running; }
        }

        private void InventoryLoop()
        {
            try
            {
                int consecutiveErrors = 0;
                int backoffMs = PollIntervalMs;
                bool faultReported = false;

                while (_running)
                {
                    // 已被新起的盘存线程顶替（用户断开后快速重连的场景）：自己退场，别双线程抢串口
                    if (_worker != Thread.CurrentThread)
                    {
                        break;
                    }

                    int cardNum = 0;
                    int totalLength = 0;
                    byte[] buffer = new byte[5000];
                    byte comAdr = _comAdr;
                    int comIndex = _comIndex;

                    if (comIndex == -1)
                    {
                        // 串口丢了（自动重连失败 / USB 抖动）：线程不退出，原地周期性尝试恢复，
                        // 否则 StartInventory 会被 _running 卡死，出现「已连接但永远读不到卡」
                        consecutiveErrors = 0;
                        backoffMs = PollIntervalMs;
                        if (TryRecoverReader())
                        {
                            continue;
                        }
                        Thread.Sleep(2000);
                        continue;
                    }

                    int result;
                    try
                    {
                        // AdrTID=0, LenTID=0, TIDFlag=0 表示按 EPC 盘存
                        result = StaticClassReaderB.Inventory_G2(ref comAdr, 0, 0, 0,
                            buffer, ref totalLength, ref cardNum, comIndex);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Error("盘存调用异常", ex);
                        RaiseStatus(false, "读卡器通讯异常：" + ex.Message, true);
                        break;
                    }

                    if (cardNum > 0 && totalLength > 0)
                    {
                        ParseAndRaise(buffer, totalLength, cardNum);
                    }

                    if (!IsSuccessCode(result) && result != 0)
                    {
                        // 通讯抖动：逐次拉长重试间隔（150ms → 最长 1.2s），别硬怼
                        consecutiveErrors++;
                        backoffMs = Math.Min(backoffMs * 2, 1200);
                        Thread.Sleep(backoffMs);

                        // 连续 12 次失败 ≈ 持续 3~5 秒无应答：进入自动重连
                        if (consecutiveErrors >= 12)
                        {
                            if (!faultReported)
                            {
                                faultReported = true;
                                AppLog.Warn("读卡器连续无应答（返回码 " + result + "），开始自动重连");
                                RaiseStatus(false, "读卡器响应中断，正在自动重连…", false);
                            }

                            if (TryRecoverReader())
                            {
                                AppLog.Info("读卡器自动重连成功：" + _portName);
                                consecutiveErrors = 0;
                                backoffMs = PollIntervalMs;
                                faultReported = false;
                                continue;
                            }

                            RaiseStatus(false, "读卡器已失联，请检查 USB 线是否松动；系统会持续自动重连。", true);
                            Thread.Sleep(4000);
                        }
                        continue;
                    }

                    // 恢复正常（哪怕这轮没读到卡）：把故障状态复位
                    if (faultReported)
                    {
                        faultReported = false;
                        RaiseStatus(true, string.Format("已连接 {0}（{1}）", _portName, BaudText), false);
                        AppLog.Info("读卡器通讯已恢复");
                    }
                    consecutiveErrors = 0;
                    backoffMs = PollIntervalMs;

                    Thread.Sleep(PollIntervalMs);
                }
            }
            finally
            {
                // 线程退出必须清标志：否则 StartInventory 以为还在盘存，永远不再启动
                if (_worker == Thread.CurrentThread)
                {
                    _running = false;
                }
            }
        }

        /// <summary>
        /// 尝试自动重连读卡器（在盘存线程内调用，不走 Close/Open 的公共流程以免动到工作线程）。
        /// </summary>
        private bool TryRecoverReader()
        {
            if (!_running)
            {
                return false;
            }

            lock (_sync)
            {
                if (_comIndex != -1)
                {
                    try
                    {
                        StaticClassReaderB.CloseSpecComPort(_comIndex);
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn("自动重连：关闭旧串口失败：" + ex.Message);
                    }
                    _comIndex = -1;
                    _portName = string.Empty;
                    _readerType = string.Empty;
                }
            }

            Thread.Sleep(800);

            if (!_running)
            {
                return false;
            }

            string error;
            if (!Open(_recoverPortName, _recoverBaudUiIndex, out error))
            {
                return false;
            }

            if (!_running)
            {
                // 恢复期间用户已经断开：把刚打开的串口关掉，别留着占坑
                lock (_sync)
                {
                    try
                    {
                        if (_comIndex != -1)
                        {
                            StaticClassReaderB.CloseSpecComPort(_comIndex);
                        }
                    }
                    catch
                    {
                    }
                    _comIndex = -1;
                    _portName = string.Empty;
                }
                return false;
            }

            return true;
        }

        /// <summary>SDK 中代表「正常但无新数据」的返回码。</summary>
        private static bool IsSuccessCode(int code)
        {
            return code == 0x01 || code == 0x02 || code == 0x03 || code == 0x04 || code == 0xFB;
        }

        /// <summary>
        /// 解析盘存返回的数据帧。
        /// 帧格式：每张卡为 [EPC 长度(1字节)] + [EPC 数据(EPClen 字节)]，首尾相接。
        /// 每张卡都会尝试再读一次 TID：同批卡的 EPC 可能被写成一样并锁死，
        /// 只有 TID（芯片出厂唯一编号）能把它们区分开。
        /// </summary>
        private void ParseAndRaise(byte[] buffer, int totalLength, int cardNum)
        {
            int offset = 0;
            for (int i = 0; i < cardNum; i++)
            {
                if (offset >= totalLength)
                {
                    break;
                }

                int epcLength = buffer[offset];
                offset++;

                if (epcLength <= 0 || offset + epcLength > totalLength)
                {
                    break;
                }

                string epc = HexUtil.ToHexString(buffer, offset, epcLength);
                byte[] epcBytes = new byte[epcLength];
                Array.Copy(buffer, offset, epcBytes, 0, epcLength);
                offset += epcLength;

                if (epc.Length == 0)
                {
                    continue;
                }

                string tid = string.Empty;
                if (UseTidAsCardNo)
                {
                    tid = TryReadTid(epcBytes);
                    if (tid.Length == 0)
                    {
                        AppLog.Warn("读取 TID 失败，卡号退回 EPC：" + epc);
                    }
                }

                string cardNo = tid.Length > 0 ? tid : epc;

                if (ShouldReport(cardNo))
                {
                    EventHandler<TagReadEventArgs> handler = TagRead;
                    if (handler != null)
                    {
                        try
                        {
                            handler(this, new TagReadEventArgs(epc, tid));
                        }
                        catch (Exception ex)
                        {
                            AppLog.Error("处理刷卡事件异常", ex);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 读取标签的 TID（存储区 0x02，从第 0 个字开始）。
        /// 不同芯片 TID 长度不一样（4 / 8 / 12 字节都有），读 6 个字失败就依次降为 4 个字、2 个字。
        /// 任何一步不成功都返回空字符串，由调用方退回 EPC。
        /// </summary>
        private string TryReadTid(byte[] epcBytes)
        {
            if (epcBytes == null || epcBytes.Length == 0 || epcBytes.Length > 255)
            {
                return string.Empty;
            }

            byte[] data = new byte[64];
            int[] wordCounts = new int[] { 6, 4, 2 };

            // 两轮尝试：串口抖动时第一轮常失败，隔 30ms 再试一轮能救回不少
            for (int round = 0; round < 2; round++)
            {
                if (round > 0)
                {
                    Thread.Sleep(30);
                }

                for (int i = 0; i < wordCounts.Length; i++)
                {
                    int words = wordCounts[i];
                    try
                    {
                        byte comAdr = _comAdr;
                        int comIndex = _comIndex;
                        if (comIndex == -1)
                        {
                            return string.Empty;
                        }

                        byte[] password = new byte[4];
                        int errorCode = 0;
                        byte[] dataBuffer = new byte[words * 2 + 8];

                        int result = StaticClassReaderB.ReadCard_G2(ref comAdr, epcBytes,
                            0x02, 0, (byte)words, password, 0, 0, 0,
                            dataBuffer, (byte)epcBytes.Length, ref errorCode, comIndex);

                        if (result == 0)
                        {
                            string tid = HexUtil.ToHexString(dataBuffer, 0, words * 2);
                            if (tid.Length > 0 && tid != "000000000000000000000000")
                            {
                                return tid;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        AppLog.Warn("读取 TID 异常：" + ex.Message);
                        return string.Empty;
                    }
                }
            }

            return string.Empty;
        }

        /// <summary>同一张卡在 ReportIntervalMs 内只上报一次。</summary>
        private bool ShouldReport(string epc)
        {
            DateTime now = DateTime.Now;
            lock (_sync)
            {
                DateTime last;
                if (_recentTags.TryGetValue(epc, out last) &&
                    (now - last).TotalMilliseconds < ReportIntervalMs)
                {
                    return false;
                }
                _recentTags[epc] = now;

                // 定期清理过期条目，避免字典无限增长
                if ((now - _lastCleanup).TotalSeconds > 30)
                {
                    _lastCleanup = now;
                    List<string> expired = new List<string>();
                    foreach (KeyValuePair<string, DateTime> pair in _recentTags)
                    {
                        if ((now - pair.Value).TotalSeconds > 60)
                        {
                            expired.Add(pair.Key);
                        }
                    }
                    for (int i = 0; i < expired.Count; i++)
                    {
                        _recentTags.Remove(expired[i]);
                    }
                }
            }
            return true;
        }

        #endregion

        private void RaiseStatus(bool connected, string message, bool isError)
        {
            EventHandler<ReaderStatusEventArgs> handler = StatusChanged;
            if (handler != null)
            {
                try
                {
                    handler(this, new ReaderStatusEventArgs(connected, message, isError));
                }
                catch (Exception ex)
                {
                    AppLog.Error("处理状态事件异常", ex);
                }
            }
        }

        public void Dispose()
        {
            Close();
        }
    }
}
