﻿// 打卡页
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Media;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Models;
using RfidAttendance.Services;

// ---------------------------------------------------------------
// 来源：Forms\FrmCheckIn.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 打卡签到页：等待刷卡 → 展示打卡结果 → 刷新今日统计与最近记录。
    /// </summary>
    public partial class FrmCheckIn : Form, ITagConsumer, IPageView
    {
        private readonly AttendanceService _attendance = new AttendanceService();
        private readonly AttendanceRepository _attendanceRepo = new AttendanceRepository();
        private readonly EmployeeRepository _employeeRepo = new EmployeeRepository();

        private Timer _clockTimer;

        public FrmCheckIn()
        {
            InitializeComponent();
            AppTheme.ApplyForm(this);

            AppTheme.StyleSecondaryButton(btnManual);
            AppTheme.StyleGrid(gridRecent);

            gridRecent.Columns["colTime"].FillWeight = 22F;
            gridRecent.Columns["colName"].FillWeight = 20F;
            gridRecent.Columns["colEmpNo"].FillWeight = 22F;
            gridRecent.Columns["colDept"].FillWeight = 22F;
            gridRecent.Columns["colType"].FillWeight = 14F;

            btnManual.Click += btnManual_Click;

            _clockTimer = new Timer();
            _clockTimer.Interval = 1000;
            _clockTimer.Tick += OnClockTick;
            _clockTimer.Start();

            Load += OnCheckInLoad;
            FormClosed += OnCheckInClosed;
        }

        #region 生命周期

        private void OnCheckInLoad(object sender, EventArgs e)
        {
            UpdateClock();
            SetIdleState();
            RefreshAll();
        }

        private void OnCheckInClosed(object sender, EventArgs e)
        {
            if (_clockTimer != null)
            {
                _clockTimer.Stop();
                _clockTimer.Dispose();
                _clockTimer = null;
            }
        }

        private void OnClockTick(object sender, EventArgs e)
        {
            UpdateClock();
        }

        private void UpdateClock()
        {
            DateTime now = DateTime.Now;
            labClock.Text = now.ToString("HH:mm:ss");
            labDate.Text = now.ToString("yyyy年M月d日 dddd", System.Globalization.CultureInfo.GetCultureInfo("zh-CN"));

            int hour = now.Hour;
            string greeting;
            if (hour < 6)
            {
                greeting = "夜深了";
            }
            else if (hour < 11)
            {
                greeting = "早上好";
            }
            else if (hour < 14)
            {
                greeting = "中午好";
            }
            else if (hour < 18)
            {
                greeting = "下午好";
            }
            else
            {
                greeting = "晚上好";
            }
            labGreeting.Text = greeting + "，请刷卡打卡";
        }

        #endregion

        #region 刷卡处理

        /// <summary>FrmMain 把刷卡事件转发到这里。</summary>
        public void HandleTag(string epc)
        {
            if (!IsHandleCreated || IsDisposed)
            {
                return;
            }

            try
            {
                PunchResult result = _attendance.HandleCard(epc);
                ShowResult(result);
                RefreshAll();
            }
            catch (Exception ex)
            {
                AppLog.Error("打卡页处理刷卡失败", ex);
            }
        }

        private void ShowResult(PunchResult result)
        {
            Color color;
            string badge;
            string name;
            string info;

            switch (result.Status)
            {
                case PunchStatus.Success:
                    if (result.Record.PunchType == PunchType.CheckIn)
                    {
                        color = AppTheme.Success;
                        badge = "上班签到";
                    }
                    else
                    {
                        color = AppTheme.Primary;
                        badge = "下班签退";
                    }
                    name = result.Employee.Name;
                    info = string.Format("工号 {0}　{1}",
                        result.Employee.EmpNo,
                        string.IsNullOrEmpty(result.Employee.Department) ? "未设置部门" : result.Employee.Department);
                    SystemSounds.Asterisk.Play();
                    break;

                case PunchStatus.Duplicate:
                    color = AppTheme.Warning;
                    badge = "重复刷卡";
                    name = result.Employee != null ? result.Employee.Name : "—";
                    info = result.Message;
                    break;

                case PunchStatus.CardNotBound:
                    color = AppTheme.Danger;
                    badge = "未登记卡";
                    name = "未登记的卡片";
                    info = "请先到「员工管理」中把这张卡绑定给员工";
                    SystemSounds.Hand.Play();
                    break;

                case PunchStatus.EmployeeDisabled:
                    color = AppTheme.Danger;
                    badge = "账号停用";
                    name = result.Employee != null ? result.Employee.Name : "—";
                    info = result.Message;
                    SystemSounds.Hand.Play();
                    break;

                default:
                    color = AppTheme.Danger;
                    badge = "读卡异常";
                    name = "读卡失败";
                    info = result.Message;
                    SystemSounds.Hand.Play();
                    break;
            }

            labStatusIcon.ForeColor = color;
            labBadge.Text = badge;
            labBadge.BackColor = Lighten(color);
            labBadge.ForeColor = color;
            labName.Text = name;
            labInfo.Text = info;
            labTime.Text = result.OccurredAt.ToString("HH:mm:ss");
            labTimeCaption.Text = result.IsSuccess ? "打卡时间" : "刷卡时间";
        }

        /// <summary>把状态色调淡，用作品牌标签底色。</summary>
        private static Color Lighten(Color c)
        {
            const double ratio = 0.87;
            return Color.FromArgb(
                (int)(c.R + (255 - c.R) * ratio),
                (int)(c.G + (255 - c.G) * ratio),
                (int)(c.B + (255 - c.B) * ratio));
        }

        private void SetIdleState()
        {
            labStatusIcon.ForeColor = Color.FromArgb(203, 213, 225);
            labBadge.Text = "待机中";
            labBadge.BackColor = Color.FromArgb(241, 245, 249);
            labBadge.ForeColor = AppTheme.TextSecondary;
            labName.Text = "等待刷卡";
            labInfo.Text = "请将工牌靠近读卡器完成打卡";
            labTime.Text = DateTime.Now.ToString("HH:mm:ss");
            labTimeCaption.Text = "当前时间";
        }

        #endregion

        #region 数据刷新

        private void RefreshAll()
        {
            RefreshStats();
            RefreshRecent();
        }

        private void RefreshStats()
        {
            try
            {
                int people = _attendance.GetTodayPeopleCount();
                int total = _employeeRepo.Count();
                int records = _attendance.GetTodayRecordCount();

                labPeopleValue.Text = people.ToString();
                labPeopleCaption.Text = string.Format("人已打卡 / 共 {0} 人", total);
                labRecordValue.Text = records.ToString();
            }
            catch (Exception ex)
            {
                AppLog.Error("刷新今日统计失败", ex);
            }
        }

        private void RefreshRecent()
        {
            try
            {
                string today = DateTime.Now.ToString("yyyy-MM-dd");
                List<AttendanceRecord> list = _attendanceRepo.Query(today, today, null);

                gridRecent.Rows.Clear();
                int max = 20;
                for (int i = 0; i < list.Count && i < max; i++)
                {
                    AttendanceRecord r = list[i];
                    gridRecent.Rows.Add(
                        r.PunchTimeOnlyText,
                        r.EmpName,
                        r.EmpNo,
                        string.IsNullOrEmpty(r.Department) ? "—" : r.Department,
                        r.PunchTypeText);
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("刷新最近记录失败", ex);
            }
        }

        public void OnPageShown()
        {
            UpdateClock();
            RefreshAll();
        }

        #endregion

        private void btnManual_Click(object sender, EventArgs e)
        {
            string card = InputDialog.Show(this, "手动输入卡号",
                "没有连接读卡器时，可以在这里输入卡号模拟刷卡。\r\n（卡号即标签的 EPC，十六进制，例如 E2003412A1B2C3D4）",
                string.Empty);

            if (!string.IsNullOrEmpty(card))
            {
                HandleTag(card);
            }
        }
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmCheckIn.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmCheckIn
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.labGreeting = new System.Windows.Forms.Label();
            this.labSubGreeting = new System.Windows.Forms.Label();
            this.labClock = new System.Windows.Forms.Label();
            this.labDate = new System.Windows.Forms.Label();
            this.panelResult = new System.Windows.Forms.Panel();
            this.labStatusIcon = new System.Windows.Forms.Label();
            this.labName = new System.Windows.Forms.Label();
            this.labInfo = new System.Windows.Forms.Label();
            this.labBadge = new System.Windows.Forms.Label();
            this.labTime = new System.Windows.Forms.Label();
            this.labTimeCaption = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.panelRecent = new System.Windows.Forms.Panel();
            this.labRecentTitle = new System.Windows.Forms.Label();
            this.gridRecent = new System.Windows.Forms.DataGridView();
            this.colTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEmpNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelStats = new System.Windows.Forms.Panel();
            this.labStatTitle = new System.Windows.Forms.Label();
            this.labPeopleValue = new System.Windows.Forms.Label();
            this.labPeopleCaption = new System.Windows.Forms.Label();
            this.labRecordValue = new System.Windows.Forms.Label();
            this.labRecordCaption = new System.Windows.Forms.Label();
            this.btnManual = new System.Windows.Forms.Button();
            this.labStatsHint = new System.Windows.Forms.Label();
            this.panelTop.SuspendLayout();
            this.panelResult.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.panelRecent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridRecent)).BeginInit();
            this.panelStats.SuspendLayout();
            this.SuspendLayout();
            //
            // panelTop
            //
            this.panelTop.BackColor = System.Drawing.Color.Transparent;
            this.panelTop.Controls.Add(this.labGreeting);
            this.panelTop.Controls.Add(this.labSubGreeting);
            this.panelTop.Controls.Add(this.labClock);
            this.panelTop.Controls.Add(this.labDate);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(948, 84);
            this.panelTop.TabIndex = 0;
            //
            // labGreeting
            //
            this.labGreeting.AutoSize = true;
            this.labGreeting.Font = new System.Drawing.Font("微软雅黑", 18F, System.Drawing.FontStyle.Bold);
            this.labGreeting.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labGreeting.Location = new System.Drawing.Point(2, 6);
            this.labGreeting.Name = "labGreeting";
            this.labGreeting.Size = new System.Drawing.Size(158, 31);
            this.labGreeting.TabIndex = 0;
            this.labGreeting.Text = "请刷卡打卡";
            //
            // labSubGreeting
            //
            this.labSubGreeting.AutoSize = true;
            this.labSubGreeting.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labSubGreeting.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labSubGreeting.Location = new System.Drawing.Point(5, 48);
            this.labSubGreeting.Name = "labSubGreeting";
            this.labSubGreeting.Size = new System.Drawing.Size(290, 17);
            this.labSubGreeting.TabIndex = 1;
            this.labSubGreeting.Text = "把工牌靠近读卡器，系统会自动判断上班或下班";
            //
            // labClock
            //
            this.labClock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labClock.Font = new System.Drawing.Font("微软雅黑", 22F, System.Drawing.FontStyle.Bold);
            this.labClock.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.labClock.Location = new System.Drawing.Point(668, 2);
            this.labClock.Name = "labClock";
            this.labClock.Size = new System.Drawing.Size(280, 44);
            this.labClock.TabIndex = 2;
            this.labClock.Text = "00:00:00";
            this.labClock.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // labDate
            //
            this.labDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labDate.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labDate.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labDate.Location = new System.Drawing.Point(668, 48);
            this.labDate.Name = "labDate";
            this.labDate.Size = new System.Drawing.Size(280, 24);
            this.labDate.TabIndex = 3;
            this.labDate.Text = "—";
            this.labDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // panelResult
            //
            this.panelResult.BackColor = System.Drawing.Color.White;
            this.panelResult.Controls.Add(this.labStatusIcon);
            this.panelResult.Controls.Add(this.labName);
            this.panelResult.Controls.Add(this.labInfo);
            this.panelResult.Controls.Add(this.labBadge);
            this.panelResult.Controls.Add(this.labTime);
            this.panelResult.Controls.Add(this.labTimeCaption);
            this.panelResult.Location = new System.Drawing.Point(0, 92);
            this.panelResult.Name = "panelResult";
            this.panelResult.Size = new System.Drawing.Size(948, 226);
            this.panelResult.TabIndex = 1;
            //
            // labStatusIcon
            //
            this.labStatusIcon.Font = new System.Drawing.Font("微软雅黑", 44F, System.Drawing.FontStyle.Bold);
            this.labStatusIcon.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.labStatusIcon.Location = new System.Drawing.Point(34, 62);
            this.labStatusIcon.Name = "labStatusIcon";
            this.labStatusIcon.Size = new System.Drawing.Size(96, 96);
            this.labStatusIcon.TabIndex = 0;
            this.labStatusIcon.Text = "●";
            this.labStatusIcon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // labName
            //
            this.labName.AutoSize = true;
            this.labName.Font = new System.Drawing.Font("微软雅黑", 32F, System.Drawing.FontStyle.Bold);
            this.labName.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labName.Location = new System.Drawing.Point(148, 56);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(182, 57);
            this.labName.TabIndex = 1;
            this.labName.Text = "等待刷卡";
            //
            // labInfo
            //
            this.labInfo.AutoSize = true;
            this.labInfo.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.labInfo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labInfo.Location = new System.Drawing.Point(153, 124);
            this.labInfo.Name = "labInfo";
            this.labInfo.Size = new System.Drawing.Size(246, 20);
            this.labInfo.TabIndex = 2;
            this.labInfo.Text = "请将工牌靠近读卡器完成打卡";
            //
            // labBadge
            //
            this.labBadge.BackColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.labBadge.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.labBadge.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labBadge.Location = new System.Drawing.Point(152, 158);
            this.labBadge.Name = "labBadge";
            this.labBadge.Size = new System.Drawing.Size(128, 34);
            this.labBadge.TabIndex = 3;
            this.labBadge.Text = "待机中";
            this.labBadge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // labTime
            //
            this.labTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labTime.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Bold);
            this.labTime.ForeColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.labTime.Location = new System.Drawing.Point(600, 62);
            this.labTime.Name = "labTime";
            this.labTime.Size = new System.Drawing.Size(310, 58);
            this.labTime.TabIndex = 4;
            this.labTime.Text = "00:00:00";
            this.labTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // labTimeCaption
            //
            this.labTimeCaption.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labTimeCaption.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labTimeCaption.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labTimeCaption.Location = new System.Drawing.Point(600, 126);
            this.labTimeCaption.Name = "labTimeCaption";
            this.labTimeCaption.Size = new System.Drawing.Size(310, 24);
            this.labTimeCaption.TabIndex = 5;
            this.labTimeCaption.Text = "当前时间";
            this.labTimeCaption.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // panelBottom
            //
            this.panelBottom.Controls.Add(this.panelRecent);
            this.panelBottom.Controls.Add(this.panelStats);
            this.panelBottom.Location = new System.Drawing.Point(0, 330);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(948, 262);
            this.panelBottom.TabIndex = 2;
            //
            // panelRecent
            //
            this.panelRecent.BackColor = System.Drawing.Color.White;
            this.panelRecent.Controls.Add(this.labRecentTitle);
            this.panelRecent.Controls.Add(this.gridRecent);
            this.panelRecent.Location = new System.Drawing.Point(308, 0);
            this.panelRecent.Name = "panelRecent";
            this.panelRecent.Size = new System.Drawing.Size(640, 262);
            this.panelRecent.TabIndex = 1;
            //
            // labRecentTitle
            //
            this.labRecentTitle.AutoSize = true;
            this.labRecentTitle.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.labRecentTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labRecentTitle.Location = new System.Drawing.Point(18, 18);
            this.labRecentTitle.Name = "labRecentTitle";
            this.labRecentTitle.Size = new System.Drawing.Size(94, 19);
            this.labRecentTitle.TabIndex = 0;
            this.labRecentTitle.Text = "最近打卡记录";
            //
            // gridRecent
            //
            this.gridRecent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridRecent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colTime,
            this.colName,
            this.colEmpNo,
            this.colDept,
            this.colType});
            this.gridRecent.Location = new System.Drawing.Point(18, 48);
            this.gridRecent.Name = "gridRecent";
            this.gridRecent.Size = new System.Drawing.Size(604, 196);
            this.gridRecent.TabIndex = 1;
            //
            // colTime
            //
            this.colTime.HeaderText = "时间";
            this.colTime.Name = "colTime";
            //
            // colName
            //
            this.colName.HeaderText = "姓名";
            this.colName.Name = "colName";
            //
            // colEmpNo
            //
            this.colEmpNo.HeaderText = "工号";
            this.colEmpNo.Name = "colEmpNo";
            //
            // colDept
            //
            this.colDept.HeaderText = "部门";
            this.colDept.Name = "colDept";
            //
            // colType
            //
            this.colType.HeaderText = "类型";
            this.colType.Name = "colType";
            //
            // panelStats
            //
            this.panelStats.BackColor = System.Drawing.Color.White;
            this.panelStats.Controls.Add(this.labStatTitle);
            this.panelStats.Controls.Add(this.labPeopleValue);
            this.panelStats.Controls.Add(this.labPeopleCaption);
            this.panelStats.Controls.Add(this.labRecordValue);
            this.panelStats.Controls.Add(this.labRecordCaption);
            this.panelStats.Controls.Add(this.labStatsHint);
            this.panelStats.Controls.Add(this.btnManual);
            this.panelStats.Location = new System.Drawing.Point(0, 0);
            this.panelStats.Name = "panelStats";
            this.panelStats.Size = new System.Drawing.Size(296, 262);
            this.panelStats.TabIndex = 0;
            //
            // labStatTitle
            //
            this.labStatTitle.AutoSize = true;
            this.labStatTitle.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold);
            this.labStatTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labStatTitle.Location = new System.Drawing.Point(24, 18);
            this.labStatTitle.Name = "labStatTitle";
            this.labStatTitle.Size = new System.Drawing.Size(94, 19);
            this.labStatTitle.TabIndex = 0;
            this.labStatTitle.Text = "今日考勤概览";
            //
            // labPeopleValue
            //
            this.labPeopleValue.AutoSize = true;
            this.labPeopleValue.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Bold);
            this.labPeopleValue.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.labPeopleValue.Location = new System.Drawing.Point(22, 42);
            this.labPeopleValue.Name = "labPeopleValue";
            this.labPeopleValue.Size = new System.Drawing.Size(53, 52);
            this.labPeopleValue.TabIndex = 1;
            this.labPeopleValue.Text = "0";
            //
            // labPeopleCaption
            //
            this.labPeopleCaption.AutoSize = true;
            this.labPeopleCaption.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labPeopleCaption.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labPeopleCaption.Location = new System.Drawing.Point(26, 96);
            this.labPeopleCaption.Name = "labPeopleCaption";
            this.labPeopleCaption.Size = new System.Drawing.Size(130, 17);
            this.labPeopleCaption.TabIndex = 2;
            this.labPeopleCaption.Text = "人已打卡 / 共 0 人";
            //
            // labRecordValue
            //
            this.labRecordValue.AutoSize = true;
            this.labRecordValue.Font = new System.Drawing.Font("微软雅黑", 30F, System.Drawing.FontStyle.Bold);
            this.labRecordValue.ForeColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.labRecordValue.Location = new System.Drawing.Point(22, 120);
            this.labRecordValue.Name = "labRecordValue";
            this.labRecordValue.Size = new System.Drawing.Size(53, 52);
            this.labRecordValue.TabIndex = 3;
            this.labRecordValue.Text = "0";
            //
            // labRecordCaption
            //
            this.labRecordCaption.AutoSize = true;
            this.labRecordCaption.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labRecordCaption.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labRecordCaption.Location = new System.Drawing.Point(26, 174);
            this.labRecordCaption.Name = "labRecordCaption";
            this.labRecordCaption.Size = new System.Drawing.Size(100, 17);
            this.labRecordCaption.TabIndex = 4;
            this.labRecordCaption.Text = "笔考勤记录";
            //
            // labStatsHint
            //
            this.labStatsHint.AutoSize = true;
            this.labStatsHint.Font = new System.Drawing.Font("微软雅黑", 8F);
            this.labStatsHint.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labStatsHint.Location = new System.Drawing.Point(24, 200);
            this.labStatsHint.Name = "labStatsHint";
            this.labStatsHint.Size = new System.Drawing.Size(180, 16);
            this.labStatsHint.TabIndex = 5;
            this.labStatsHint.Text = "没有读卡器时可手动输入卡号";
            //
            // btnManual
            //
            this.btnManual.Location = new System.Drawing.Point(24, 220);
            this.btnManual.Name = "btnManual";
            this.btnManual.Size = new System.Drawing.Size(248, 32);
            this.btnManual.TabIndex = 6;
            this.btnManual.Text = "手动输入卡号";
            this.btnManual.UseVisualStyleBackColor = true;
            //
            // FrmCheckIn
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.ClientSize = new System.Drawing.Size(948, 592);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelResult);
            this.Controls.Add(this.panelTop);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.Name = "FrmCheckIn";
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelResult.ResumeLayout(false);
            this.panelResult.PerformLayout();
            this.panelBottom.ResumeLayout(false);
            this.panelRecent.ResumeLayout(false);
            this.panelRecent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridRecent)).EndInit();
            this.panelStats.ResumeLayout(false);
            this.panelStats.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label labGreeting;
        private System.Windows.Forms.Label labSubGreeting;
        private System.Windows.Forms.Label labClock;
        private System.Windows.Forms.Label labDate;
        private System.Windows.Forms.Panel panelResult;
        private System.Windows.Forms.Label labStatusIcon;
        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.Label labInfo;
        private System.Windows.Forms.Label labBadge;
        private System.Windows.Forms.Label labTime;
        private System.Windows.Forms.Label labTimeCaption;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelStats;
        private System.Windows.Forms.Label labStatTitle;
        private System.Windows.Forms.Label labPeopleValue;
        private System.Windows.Forms.Label labPeopleCaption;
        private System.Windows.Forms.Label labRecordValue;
        private System.Windows.Forms.Label labRecordCaption;
        private System.Windows.Forms.Label labStatsHint;
        private System.Windows.Forms.Button btnManual;
        private System.Windows.Forms.Panel panelRecent;
        private System.Windows.Forms.Label labRecentTitle;
        private System.Windows.Forms.DataGridView gridRecent;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmpNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDept;
        private System.Windows.Forms.DataGridViewTextBoxColumn colType;
    }
}
