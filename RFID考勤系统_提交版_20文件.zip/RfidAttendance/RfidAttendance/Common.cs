﻿// 通用工具：日志、十六进制转换、界面主题、输入对话框
using System;
using System.IO;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

// ---------------------------------------------------------------
// 来源：Common\AppLog.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Common
{
    /// <summary>
    /// 极简文件日志：写到程序目录下的 logs\yyyy-MM-dd.log。
    /// 硬件通讯出问题时排查最有用。
    /// </summary>
    public static class AppLog
    {
        private static readonly object SyncRoot = new object();

        public static string LogDirectory
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs"); }
        }

        public static void Info(string message)
        {
            Write("INFO ", message, null);
        }

        public static void Warn(string message)
        {
            Write("WARN ", message, null);
        }

        public static void Error(string message, Exception ex)
        {
            Write("ERROR", message, ex);
        }

        private static void Write(string level, string message, Exception ex)
        {
            try
            {
                lock (SyncRoot)
                {
                    if (!Directory.Exists(LogDirectory))
                    {
                        Directory.CreateDirectory(LogDirectory);
                    }

                    string file = Path.Combine(LogDirectory,
                        DateTime.Now.ToString("yyyy-MM-dd") + ".log");

                    StringBuilder sb = new StringBuilder();
                    sb.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
                    sb.Append(" [").Append(level).Append("] ");
                    sb.Append(message);
                    if (ex != null)
                    {
                        sb.AppendLine();
                        sb.Append("        ").Append(ex.GetType().Name).Append(": ").Append(ex.Message);
                        if (!string.IsNullOrEmpty(ex.StackTrace))
                        {
                            sb.AppendLine();
                            sb.Append(ex.StackTrace);
                        }
                    }
                    sb.AppendLine();

                    File.AppendAllText(file, sb.ToString(), Encoding.UTF8);
                }
            }
            catch
            {
                // 记日志本身失败时忽略，不能影响主流程
            }
        }
    }
}

// ---------------------------------------------------------------
// 来源：Common\HexUtil.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Common
{
    /// <summary>十六进制字符串与字节数组之间的转换工具。</summary>
    public static class HexUtil
    {
        private const string HexChars = "0123456789ABCDEF";

        /// <summary>字节数组转大写十六进制字符串（无分隔符）。</summary>
        public static string ToHexString(byte[] data)
        {
            if (data == null || data.Length == 0)
            {
                return string.Empty;
            }
            StringBuilder sb = new StringBuilder(data.Length * 2);
            for (int i = 0; i < data.Length; i++)
            {
                sb.Append(HexChars[data[i] >> 4]);
                sb.Append(HexChars[data[i] & 0x0F]);
            }
            return sb.ToString();
        }

        /// <summary>字节数组转十六进制字符串，可指定长度。</summary>
        public static string ToHexString(byte[] data, int offset, int length)
        {
            if (data == null || length <= 0)
            {
                return string.Empty;
            }
            if (offset < 0) offset = 0;
            if (offset + length > data.Length) length = data.Length - offset;

            StringBuilder sb = new StringBuilder(length * 2);
            for (int i = offset; i < offset + length; i++)
            {
                sb.Append(HexChars[data[i] >> 4]);
                sb.Append(HexChars[data[i] & 0x0F]);
            }
            return sb.ToString();
        }

        /// <summary>十六进制字符串转字节数组，返回 null 表示格式非法。</summary>
        public static byte[] FromHexString(string hex)
        {
            if (string.IsNullOrEmpty(hex))
            {
                return new byte[0];
            }

            StringBuilder clean = new StringBuilder(hex.Length);
            for (int i = 0; i < hex.Length; i++)
            {
                char c = hex[i];
                if (Uri.IsHexDigit(c))
                {
                    clean.Append(c);
                }
            }

            if (clean.Length == 0 || clean.Length % 2 != 0)
            {
                return null;
            }

            byte[] result = new byte[clean.Length / 2];
            for (int i = 0; i < result.Length; i++)
            {
                result[i] = Convert.ToByte(clean.ToString(i * 2, 2), 16);
            }
            return result;
        }

        /// <summary>把卡号规范化：去空格、转大写，便于比对。</summary>
        public static string Normalize(string cardNo)
        {
            if (string.IsNullOrEmpty(cardNo))
            {
                return string.Empty;
            }
            return cardNo.Replace(" ", string.Empty).Replace("-", string.Empty).ToUpperInvariant();
        }
    }
}

// ---------------------------------------------------------------
// 来源：Common\AppTheme.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Common
{
    /// <summary>
    /// 全局界面主题：统一配色、字体与控件样式，避免每个窗体各写一套。
    /// </summary>
    public static class AppTheme
    {
        // ---------- 品牌色 ----------
        public static readonly Color Primary = Color.FromArgb(37, 99, 235);      // #2563EB
        public static readonly Color PrimaryDark = Color.FromArgb(29, 78, 216);
        public static readonly Color PrimarySoft = Color.FromArgb(219, 234, 254);

        // ---------- 语义色 ----------
        public static readonly Color Success = Color.FromArgb(22, 163, 74);
        public static readonly Color Danger = Color.FromArgb(220, 38, 38);
        public static readonly Color Warning = Color.FromArgb(202, 138, 4);

        // ---------- 中性色 ----------
        public static readonly Color Background = Color.FromArgb(243, 246, 251);
        public static readonly Color Surface = Color.White;
        public static readonly Color Border = Color.FromArgb(226, 232, 240);
        public static readonly Color NavBackground = Color.FromArgb(30, 41, 59);
        public static readonly Color NavHover = Color.FromArgb(51, 65, 85);

        public static readonly Color TextPrimary = Color.FromArgb(15, 23, 42);
        public static readonly Color TextSecondary = Color.FromArgb(100, 116, 139);
        public static readonly Color TextOnDark = Color.FromArgb(226, 232, 240);

        // ---------- 字体 ----------
        public const string FontFamily = "微软雅黑";

        public static Font FontNormal { get { return new Font(FontFamily, 9F); } }
        public static Font FontSmall { get { return new Font(FontFamily, 8.5F); } }
        public static Font FontBold { get { return new Font(FontFamily, 9F, FontStyle.Bold); } }
        public static Font FontTitle { get { return new Font(FontFamily, 15F, FontStyle.Bold); } }
        public static Font FontHuge { get { return new Font(FontFamily, 34F, FontStyle.Bold); } }

        /// <summary>给窗体套用统一的背景与字体。</summary>
        public static void ApplyForm(Form form)
        {
            form.BackColor = Background;
            form.Font = FontNormal;
            form.ForeColor = TextPrimary;
        }

        /// <summary>主内容区的卡片式面板。</summary>
        public static Panel CreateCard()
        {
            Panel p = new Panel();
            p.BackColor = Surface;
            p.Padding = new Padding(16);
            return p;
        }

        /// <summary>主要按钮：实心品牌色。</summary>
        public static void StylePrimaryButton(Button b)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = Primary;
            b.ForeColor = Color.White;
            b.Font = FontBold;
            b.Cursor = Cursors.Hand;
            b.Height = 32;
            b.UseVisualStyleBackColor = false;
        }

        /// <summary>次要按钮：白底描边。</summary>
        public static void StyleSecondaryButton(Button b)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 1;
            b.FlatAppearance.BorderColor = Border;
            b.BackColor = Surface;
            b.ForeColor = TextPrimary;
            b.Font = FontNormal;
            b.Cursor = Cursors.Hand;
            b.Height = 32;
            b.UseVisualStyleBackColor = false;
        }

        /// <summary>危险按钮：用于删除等操作。</summary>
        public static void StyleDangerButton(Button b)
        {
            StyleSecondaryButton(b);
            b.ForeColor = Danger;
        }

        /// <summary>把 DataGridView 调成扁平清爽样式。</summary>
        public static void StyleGrid(DataGridView grid)
        {
            grid.BackgroundColor = Surface;
            grid.BorderStyle = BorderStyle.None;
            grid.GridColor = Border;
            grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            grid.EnableHeadersVisualStyles = false;

            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = TextPrimary;
            grid.ColumnHeadersDefaultCellStyle.Font = FontBold;
            grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
            grid.ColumnHeadersHeight = 36;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            grid.DefaultCellStyle.BackColor = Surface;
            grid.DefaultCellStyle.ForeColor = TextPrimary;
            grid.DefaultCellStyle.SelectionBackColor = PrimarySoft;
            grid.DefaultCellStyle.SelectionForeColor = TextPrimary;
            grid.DefaultCellStyle.Font = FontNormal;
            grid.RowTemplate.Height = 32;

            grid.RowHeadersVisible = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.ReadOnly = true;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
}

// ---------------------------------------------------------------
// 来源：Common\InputDialog.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Common
{
    /// <summary>
    /// 极简输入对话框。WinForms 没有内置的 InputBox，
    /// 而引用 Microsoft.VisualBasic 又太重，这里自己拼一个。
    /// </summary>
    public static class InputDialog
    {
        public static string Show(IWin32Window owner, string title, string prompt, string defaultValue)
        {
            using (Form dlg = new Form())
            {
                dlg.Text = title;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.MinimizeBox = false;
                dlg.MaximizeBox = false;
                dlg.ShowInTaskbar = false;
                dlg.ClientSize = new Size(430, 176);
                dlg.BackColor = Color.White;
                dlg.Font = AppTheme.FontNormal;

                Label lab = new Label();
                lab.Text = prompt;
                lab.Location = new Point(22, 20);
                lab.Size = new Size(386, 42);
                lab.ForeColor = AppTheme.TextSecondary;

                TextBox txt = new TextBox();
                txt.Text = defaultValue ?? string.Empty;
                txt.Location = new Point(24, 68);
                txt.Size = new Size(382, 25);
                txt.Font = new Font(AppTheme.FontFamily, 10F);

                Button ok = new Button();
                ok.Text = "确定";
                ok.DialogResult = DialogResult.OK;
                ok.Location = new Point(222, 116);
                ok.Size = new Size(88, 32);
                AppTheme.StylePrimaryButton(ok);

                Button cancel = new Button();
                cancel.Text = "取消";
                cancel.DialogResult = DialogResult.Cancel;
                cancel.Location = new Point(318, 116);
                cancel.Size = new Size(88, 32);
                AppTheme.StyleSecondaryButton(cancel);

                dlg.Controls.Add(lab);
                dlg.Controls.Add(txt);
                dlg.Controls.Add(ok);
                dlg.Controls.Add(cancel);
                dlg.AcceptButton = ok;
                dlg.CancelButton = cancel;

                txt.SelectAll();
                txt.Focus();

                if (dlg.ShowDialog(owner) == DialogResult.OK)
                {
                    return txt.Text.Trim();
                }
                return null;
            }
        }
    }
}
