﻿// 员工管理页
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Hardware;
using RfidAttendance.Models;

// ---------------------------------------------------------------
// 来源：Forms\FrmEmployee.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 员工管理页：列表、增删改查，以及把 RFID 卡号绑定到员工。
    /// </summary>
    public partial class FrmEmployee : Form, ITagConsumer, IPageView
    {
        private readonly EmployeeRepository _repo = new EmployeeRepository();
        private readonly FrmMain _main;

        private List<Employee> _list = new List<Employee>();

        // 绑卡模式：处于该模式时，刷到的卡会绑定给 _bindingEmployeeId
        private bool _binding;
        private int _bindingEmployeeId;
        private string _bindingEmployeeName = string.Empty;

        /// <summary>供 Visual Studio 设计器使用。</summary>
        public FrmEmployee()
            : this(null)
        {
        }

        public FrmEmployee(FrmMain main)
        {
            InitializeComponent();
            _main = main;
            AppTheme.ApplyForm(this);

            AppTheme.StyleGrid(gridEmployee);
            AppTheme.StylePrimaryButton(btnAdd);
            AppTheme.StyleSecondaryButton(btnSearch);
            AppTheme.StyleSecondaryButton(btnReset);
            AppTheme.StyleSecondaryButton(btnEdit);
            AppTheme.StyleSecondaryButton(btnBind);
            AppTheme.StyleSecondaryButton(btnUnbind);
            AppTheme.StyleDangerButton(btnDelete);

            gridEmployee.Columns["colEmpNo"].FillWeight = 12F;
            gridEmployee.Columns["colName"].FillWeight = 12F;
            gridEmployee.Columns["colDept"].FillWeight = 15F;
            gridEmployee.Columns["colPosition"].FillWeight = 14F;
            gridEmployee.Columns["colCard"].FillWeight = 29F;
            gridEmployee.Columns["colActive"].FillWeight = 8F;
            gridEmployee.Columns["colPhone"].FillWeight = 14F;

            btnSearch.Click += btnSearch_Click;
            btnReset.Click += btnReset_Click;
            btnAdd.Click += btnAdd_Click;
            btnEdit.Click += btnEdit_Click;
            btnDelete.Click += btnDelete_Click;
            btnBind.Click += btnBind_Click;
            btnUnbind.Click += btnUnbind_Click;
            txtSearch.KeyDown += txtSearch_KeyDown;
            gridEmployee.CellDoubleClick += gridEmployee_CellDoubleClick;

            Load += OnEmployeeLoad;
        }

        #region 列表加载

        private void OnEmployeeLoad(object sender, EventArgs e)
        {
            ReloadList();
        }

        public void OnPageShown()
        {
            ReloadList();
        }

        private void ReloadList()
        {
            try
            {
                string keyword = txtSearch.Text.Trim();
                _list = keyword.Length > 0 ? _repo.Search(keyword) : _repo.GetAll();
                BindGrid();
            }
            catch (Exception ex)
            {
                AppLog.Error("加载员工列表失败", ex);
                MessageBox.Show(this, "加载员工列表失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BindGrid()
        {
            gridEmployee.Rows.Clear();
            for (int i = 0; i < _list.Count; i++)
            {
                Employee e = _list[i];
                gridEmployee.Rows.Add(
                    e.EmpNo,
                    e.Name,
                    string.IsNullOrEmpty(e.Department) ? "—" : e.Department,
                    string.IsNullOrEmpty(e.Position) ? "—" : e.Position,
                    string.IsNullOrEmpty(e.CardNo) ? "（未绑定）" : e.CardNo,
                    e.ActiveText,
                    string.IsNullOrEmpty(e.Phone) ? "—" : e.Phone);
            }

            int bound = 0;
            for (int i = 0; i < _list.Count; i++)
            {
                if (_list[i].HasCard)
                {
                    bound++;
                }
            }

            if (!_binding)
            {
                labHint.ForeColor = AppTheme.TextSecondary;
                labHint.Text = string.Format("共 {0} 名员工，其中 {1} 名已绑定卡号", _list.Count, bound);
            }
        }

        private Employee GetSelected()
        {
            if (gridEmployee.CurrentRow == null)
            {
                return null;
            }
            int index = gridEmployee.CurrentRow.Index;
            if (index < 0 || index >= _list.Count)
            {
                return null;
            }
            return _list[index];
        }

        #endregion

        #region 搜索

        private void btnSearch_Click(object sender, EventArgs e)
        {
            ReloadList();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSearch.Text = string.Empty;
            ReloadList();
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                ReloadList();
            }
        }

        #endregion

        #region 增删改

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (FrmEmployeeEdit dlg = new FrmEmployeeEdit(null, _main))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    ReloadList();
                }
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditSelected();
        }

        private void gridEmployee_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                EditSelected();
            }
        }

        private void EditSelected()
        {
            Employee emp = GetSelected();
            if (emp == null)
            {
                MessageBox.Show(this, "请先在列表里选中一名员工。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (FrmEmployeeEdit dlg = new FrmEmployeeEdit(emp, _main))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    ReloadList();
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Employee emp = GetSelected();
            if (emp == null)
            {
                MessageBox.Show(this, "请先在列表里选中一名员工。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string message = string.Format(
                "确定要删除员工「{0}（{1}）」吗？\r\n\r\n原有的考勤记录会保留，便于日后追溯。",
                emp.Name, emp.EmpNo);

            if (MessageBox.Show(this, message, "删除确认",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK)
            {
                return;
            }

            try
            {
                _repo.Delete(emp.Id);
                AppLog.Info("删除员工：" + emp.EmpNo + " " + emp.Name);
                ReloadList();
            }
            catch (Exception ex)
            {
                AppLog.Error("删除员工失败", ex);
                MessageBox.Show(this, "删除失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region 卡号绑定

        private void btnBind_Click(object sender, EventArgs e)
        {
            if (_binding)
            {
                CancelBinding("已取消绑定操作。");
                return;
            }

            Employee emp = GetSelected();
            if (emp == null)
            {
                MessageBox.Show(this, "请先在列表里选中一名员工，再刷卡绑定。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!EnsureReaderConnected())
            {
                return;
            }

            _binding = true;
            _bindingEmployeeId = emp.Id;
            _bindingEmployeeName = emp.Name;

            btnBind.Text = "取消绑定";
            labHint.ForeColor = AppTheme.Primary;
            labHint.Text = string.Format("正在等待刷卡……请把要给「{0}」使用的卡片靠近读卡器（再次点击按钮可取消）", emp.Name);
        }

        private void CancelBinding(string hint)
        {
            _binding = false;
            _bindingEmployeeId = 0;
            _bindingEmployeeName = string.Empty;
            btnBind.Text = "刷卡绑定卡号";
            labHint.ForeColor = AppTheme.TextSecondary;
            labHint.Text = hint;
            BindGrid();
        }

        /// <summary>FrmMain 在「员工管理」为当前页时把刷卡事件转发过来。</summary>
        public void HandleTag(string epc)
        {
            if (!_binding)
            {
                return;
            }

            int employeeId = _bindingEmployeeId;
            string employeeName = _bindingEmployeeName;

            try
            {
                if (_repo.CardNoExists(epc, employeeId))
                {
                    Employee owner = _repo.GetByCardNo(epc);
                    string ownerText = owner != null ? owner.Name + "（" + owner.EmpNo + "）" : "其他员工";
                    MessageBox.Show(this,
                        "这张卡已经绑定给 " + ownerText + " 了。\r\n\r\n如果要换绑，请先解除原来的绑定。",
                        "卡号已被占用", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _repo.UpdateCardNo(employeeId, epc);
                AppLog.Info(string.Format("绑卡成功：{0} -> {1}", employeeName, epc));

                CancelBinding(string.Empty);
                MessageBox.Show(this,
                    string.Format("绑定成功！\r\n\r\n{0} 的卡号：{1}", employeeName, epc),
                    "绑定成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ReloadList();
            }
            catch (Exception ex)
            {
                AppLog.Error("绑定卡号失败", ex);
                MessageBox.Show(this, "绑定失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUnbind_Click(object sender, EventArgs e)
        {
            Employee emp = GetSelected();
            if (emp == null)
            {
                MessageBox.Show(this, "请先在列表里选中一名员工。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (!emp.HasCard)
            {
                MessageBox.Show(this, string.Format("{0} 还没有绑定卡号。", emp.Name), "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show(this,
                    string.Format("确定要解除 {0} 的卡号绑定吗？\r\n\r\n卡号：{1}", emp.Name, emp.CardNo),
                    "解除绑定", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) != DialogResult.OK)
            {
                return;
            }

            try
            {
                _repo.UpdateCardNo(emp.Id, string.Empty);
                ReloadList();
            }
            catch (Exception ex)
            {
                AppLog.Error("解除绑定失败", ex);
                MessageBox.Show(this, "解除绑定失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool EnsureReaderConnected()
        {
            if (RfidReaderService.Instance.IsOpen)
            {
                return true;
            }

            MessageBox.Show(this,
                "读卡器还没有连接。\r\n\r\n请确认 USB 已插好（驱动安装后会出现 COM 口），" +
                "然后到「设备设置」页面点击「连接读卡器」。",
                "读卡器未连接", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return false;
        }

        #endregion
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmEmployee.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmEmployee
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelToolbar = new System.Windows.Forms.Panel();
            this.labSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnBind = new System.Windows.Forms.Button();
            this.btnUnbind = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panelList = new System.Windows.Forms.Panel();
            this.gridEmployee = new System.Windows.Forms.DataGridView();
            this.colEmpNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCard = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colActive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelHint = new System.Windows.Forms.Panel();
            this.labHint = new System.Windows.Forms.Label();
            this.panelToolbar.SuspendLayout();
            this.panelList.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployee)).BeginInit();
            this.panelHint.SuspendLayout();
            this.SuspendLayout();
            //
            // panelToolbar
            //
            this.panelToolbar.BackColor = System.Drawing.Color.White;
            this.panelToolbar.Controls.Add(this.labSearch);
            this.panelToolbar.Controls.Add(this.txtSearch);
            this.panelToolbar.Controls.Add(this.btnSearch);
            this.panelToolbar.Controls.Add(this.btnReset);
            this.panelToolbar.Controls.Add(this.btnAdd);
            this.panelToolbar.Controls.Add(this.btnEdit);
            this.panelToolbar.Controls.Add(this.btnBind);
            this.panelToolbar.Controls.Add(this.btnUnbind);
            this.panelToolbar.Controls.Add(this.btnDelete);
            this.panelToolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelToolbar.Location = new System.Drawing.Point(0, 0);
            this.panelToolbar.Name = "panelToolbar";
            this.panelToolbar.Size = new System.Drawing.Size(948, 54);
            this.panelToolbar.TabIndex = 0;
            //
            // labSearch
            //
            this.labSearch.AutoSize = true;
            this.labSearch.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labSearch.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labSearch.Location = new System.Drawing.Point(16, 18);
            this.labSearch.Name = "labSearch";
            this.labSearch.Size = new System.Drawing.Size(44, 17);
            this.labSearch.TabIndex = 0;
            this.labSearch.Text = "搜索：";
            //
            // txtSearch
            //
            this.txtSearch.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.txtSearch.Location = new System.Drawing.Point(66, 14);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(180, 25);
            this.txtSearch.TabIndex = 1;
            //
            // btnSearch
            //
            this.btnSearch.Location = new System.Drawing.Point(254, 13);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(70, 28);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "查询";
            this.btnSearch.UseVisualStyleBackColor = true;
            //
            // btnReset
            //
            this.btnReset.Location = new System.Drawing.Point(330, 13);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(70, 28);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "显示全部";
            this.btnReset.UseVisualStyleBackColor = true;
            //
            // btnAdd
            //
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.Location = new System.Drawing.Point(446, 13);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(84, 28);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "新增员工";
            this.btnAdd.UseVisualStyleBackColor = true;
            //
            // btnEdit
            //
            this.btnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEdit.Location = new System.Drawing.Point(536, 13);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(84, 28);
            this.btnEdit.TabIndex = 5;
            this.btnEdit.Text = "编辑资料";
            this.btnEdit.UseVisualStyleBackColor = true;
            //
            // btnBind
            //
            this.btnBind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBind.Location = new System.Drawing.Point(626, 13);
            this.btnBind.Name = "btnBind";
            this.btnBind.Size = new System.Drawing.Size(96, 28);
            this.btnBind.TabIndex = 6;
            this.btnBind.Text = "刷卡绑定卡号";
            this.btnBind.UseVisualStyleBackColor = true;
            //
            // btnUnbind
            //
            this.btnUnbind.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUnbind.Location = new System.Drawing.Point(728, 13);
            this.btnUnbind.Name = "btnUnbind";
            this.btnUnbind.Size = new System.Drawing.Size(84, 28);
            this.btnUnbind.TabIndex = 7;
            this.btnUnbind.Text = "解除绑定";
            this.btnUnbind.UseVisualStyleBackColor = true;
            //
            // btnDelete
            //
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(818, 13);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(84, 28);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "删除员工";
            this.btnDelete.UseVisualStyleBackColor = true;
            //
            // panelList
            //
            this.panelList.BackColor = System.Drawing.Color.White;
            this.panelList.Controls.Add(this.gridEmployee);
            this.panelList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelList.Location = new System.Drawing.Point(0, 54);
            this.panelList.Name = "panelList";
            this.panelList.Padding = new System.Windows.Forms.Padding(14, 12, 14, 12);
            this.panelList.Size = new System.Drawing.Size(948, 506);
            this.panelList.TabIndex = 1;
            //
            // gridEmployee
            //
            this.gridEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridEmployee.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colEmpNo,
            this.colName,
            this.colDept,
            this.colPosition,
            this.colCard,
            this.colActive,
            this.colPhone});
            this.gridEmployee.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridEmployee.Location = new System.Drawing.Point(14, 12);
            this.gridEmployee.Name = "gridEmployee";
            this.gridEmployee.Size = new System.Drawing.Size(920, 482);
            this.gridEmployee.TabIndex = 0;
            //
            // colEmpNo
            //
            this.colEmpNo.HeaderText = "工号";
            this.colEmpNo.Name = "colEmpNo";
            //
            // colName
            //
            this.colName.HeaderText = "姓名";
            this.colName.Name = "colName";
            //
            // colDept
            //
            this.colDept.HeaderText = "部门";
            this.colDept.Name = "colDept";
            //
            // colPosition
            //
            this.colPosition.HeaderText = "职位";
            this.colPosition.Name = "colPosition";
            //
            // colCard
            //
            this.colCard.HeaderText = "绑定卡号（EPC）";
            this.colCard.Name = "colCard";
            //
            // colActive
            //
            this.colActive.HeaderText = "状态";
            this.colActive.Name = "colActive";
            //
            // colPhone
            //
            this.colPhone.HeaderText = "联系电话";
            this.colPhone.Name = "colPhone";
            //
            // panelHint
            //
            this.panelHint.BackColor = System.Drawing.Color.White;
            this.panelHint.Controls.Add(this.labHint);
            this.panelHint.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelHint.Location = new System.Drawing.Point(0, 560);
            this.panelHint.Name = "panelHint";
            this.panelHint.Size = new System.Drawing.Size(948, 32);
            this.panelHint.TabIndex = 2;
            //
            // labHint
            //
            this.labHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labHint.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labHint.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labHint.Location = new System.Drawing.Point(0, 0);
            this.labHint.Name = "labHint";
            this.labHint.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.labHint.Size = new System.Drawing.Size(948, 32);
            this.labHint.TabIndex = 0;
            this.labHint.Text = "共 0 名员工";
            this.labHint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // FrmEmployee
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.ClientSize = new System.Drawing.Size(948, 592);
            this.Controls.Add(this.panelList);
            this.Controls.Add(this.panelHint);
            this.Controls.Add(this.panelToolbar);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.Name = "FrmEmployee";
            this.panelToolbar.ResumeLayout(false);
            this.panelToolbar.PerformLayout();
            this.panelList.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployee)).EndInit();
            this.panelHint.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelToolbar;
        private System.Windows.Forms.Label labSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnBind;
        private System.Windows.Forms.Button btnUnbind;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel panelList;
        private System.Windows.Forms.DataGridView gridEmployee;
        private System.Windows.Forms.Panel panelHint;
        private System.Windows.Forms.Label labHint;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEmpNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDept;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPosition;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCard;
        private System.Windows.Forms.DataGridViewTextBoxColumn colActive;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPhone;
    }
}
