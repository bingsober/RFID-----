using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;

namespace RfidAttendance
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs e)
            {
                AppLog.Error("未捕获的界面异常", e.Exception);
                MessageBox.Show("程序出现异常：\r\n" + e.Exception.Message,
                    "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                AppLog.Error("未捕获的异常", e.ExceptionObject as Exception);
            };

            // 依赖预检：缺文件时给出明确提示，而不是抛一堆加载异常
            if (!CheckDependencies())
            {
                return;
            }

            try
            {
                // 初始化本地数据库（首次运行会自动创建表结构）
                DbHelper.Initialize();
            }
            catch (Exception ex)
            {
                AppLog.Error("数据库初始化失败", ex);
                MessageBox.Show("数据库初始化失败：\r\n" + ex.Message +
                    "\r\n\r\n请确认程序目录有写入权限后重试。",
                    "启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new Forms.FrmMain());
        }

        /// <summary>
        /// 检查运行必需的文件是否都在程序目录下。
        /// 读卡器 SDK 的原生库只提供 32 位版本，所以本程序必须编译为 x86。
        /// </summary>
        private static bool CheckDependencies()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;

            string[,] required = new string[,]
            {
                { "System.Data.SQLite.dll",  "SQLite 托管程序集" },
                { @"x86\SQLite.Interop.dll", "SQLite 原生库（32 位）" },
                { "UHFReader18CSharp.dll",   "读卡器 SDK" },
                { "Basic.dll",               "读卡器通讯库" }
            };

            List<string> missing = new List<string>();
            for (int i = 0; i < required.GetLength(0); i++)
            {
                string file = Path.Combine(baseDir, required[i, 0]);
                if (!File.Exists(file))
                {
                    missing.Add(required[i, 0] + "　（" + required[i, 1] + "）");
                }
            }

            if (missing.Count == 0)
            {
                return true;
            }

            string message = "缺少以下运行文件，程序无法启动：\r\n\r\n　· " +
                string.Join("\r\n　· ", missing.ToArray()) +
                "\r\n\r\n程序目录：\r\n" + baseDir +
                "\r\n\r\n解决办法：\r\n" +
                "1. 在 Visual Studio 里重新生成解决方案（选 x86 平台）；\r\n" +
                "2. 确认项目 libs 目录下的文件完整；\r\n" +
                "3. 不要单独把 exe 拷走，要和这些 DLL 一起。";

            MessageBox.Show(message, "启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
            AppLog.Error("依赖检查失败：" + string.Join("; ", missing.ToArray()), null);
            return false;
        }
    }
}
