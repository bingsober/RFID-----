﻿// 考勤查询页
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Models;

// ---------------------------------------------------------------
// 来源：Forms\FrmQuery.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 考勤查询页：按日期区间 + 员工关键字查询，支持明细与按人按天汇总两种视图，可导出 CSV。
    /// </summary>
    public partial class FrmQuery : Form, IPageView
    {
        private readonly AttendanceRepository _repo = new AttendanceRepository();

        private List<AttendanceRecord> _details = new List<AttendanceRecord>();
        private List<AttendanceSummary> _summaries = new List<AttendanceSummary>();

        public FrmQuery()
        {
            InitializeComponent();
            AppTheme.ApplyForm(this);

            AppTheme.StyleGrid(gridDetail);
            AppTheme.StyleGrid(gridSummary);
            AppTheme.StylePrimaryButton(btnQuery);
            AppTheme.StyleSecondaryButton(btnExport);
            AppTheme.StyleSecondaryButton(btnToday);
            AppTheme.StyleSecondaryButton(btnThisMonth);

            gridDetail.Columns["colDDate"].FillWeight = 14F;
            gridDetail.Columns["colDTime"].FillWeight = 13F;
            gridDetail.Columns["colDEmpNo"].FillWeight = 14F;
            gridDetail.Columns["colDName"].FillWeight = 13F;
            gridDetail.Columns["colDDept"].FillWeight = 16F;
            gridDetail.Columns["colDType"].FillWeight = 10F;
            gridDetail.Columns["colDCard"].FillWeight = 30F;

            gridSummary.Columns["colSDate"].FillWeight = 13F;
            gridSummary.Columns["colSEmpNo"].FillWeight = 12F;
            gridSummary.Columns["colSName"].FillWeight = 12F;
            gridSummary.Columns["colSDept"].FillWeight = 15F;
            gridSummary.Columns["colSIn"].FillWeight = 13F;
            gridSummary.Columns["colSOut"].FillWeight = 13F;
            gridSummary.Columns["colSDuration"].FillWeight = 12F;
            gridSummary.Columns["colSStatus"].FillWeight = 12F;

            btnQuery.Click += btnQuery_Click;
            btnExport.Click += btnExport_Click;
            btnToday.Click += btnToday_Click;
            btnThisMonth.Click += btnThisMonth_Click;
            txtKeyword.KeyDown += txtKeyword_KeyDown;

            Load += OnQueryLoad;
        }

        #region 生命周期

        private void OnQueryLoad(object sender, EventArgs e)
        {
            SetThisMonthRange();
            RunQuery();
        }

        public void OnPageShown()
        {
            // 用户可能刚打完卡，重新查询一次让数据保持最新
            RunQuery();
        }

        #endregion

        #region 快捷日期

        private void btnToday_Click(object sender, EventArgs e)
        {
            dtpFrom.Value = DateTime.Today;
            dtpTo.Value = DateTime.Today;
            RunQuery();
        }

        private void btnThisMonth_Click(object sender, EventArgs e)
        {
            SetThisMonthRange();
            RunQuery();
        }

        private void SetThisMonthRange()
        {
            DateTime today = DateTime.Today;
            dtpFrom.Value = new DateTime(today.Year, today.Month, 1);
            dtpTo.Value = today;
        }

        private void txtKeyword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                RunQuery();
            }
        }

        #endregion

        #region 查询

        private void btnQuery_Click(object sender, EventArgs e)
        {
            RunQuery();
        }

        private void RunQuery()
        {
            string from = dtpFrom.Value.ToString("yyyy-MM-dd");
            string to = dtpTo.Value.ToString("yyyy-MM-dd");
            string keyword = txtKeyword.Text.Trim();

            if (string.CompareOrdinal(from, to) > 0)
            {
                MessageBox.Show(this, "开始日期不能晚于结束日期。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                Cursor = Cursors.WaitCursor;

                _details = _repo.Query(from, to, keyword);
                _summaries = _repo.QuerySummary(from, to, keyword);

                BindDetail();
                BindSummary();

                labCount.Text = string.Format(
                    "查询范围 {0} ~ {1}{2}　|　明细 {3} 条，汇总 {4} 行",
                    from, to,
                    keyword.Length > 0 ? "，关键字「" + keyword + "」" : string.Empty,
                    _details.Count, _summaries.Count);
            }
            catch (Exception ex)
            {
                AppLog.Error("查询考勤失败", ex);
                MessageBox.Show(this, "查询失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        private void BindDetail()
        {
            gridDetail.Rows.Clear();
            for (int i = 0; i < _details.Count; i++)
            {
                AttendanceRecord r = _details[i];
                gridDetail.Rows.Add(
                    r.WorkDate,
                    r.PunchTimeOnlyText,
                    r.EmpNo,
                    r.EmpName,
                    string.IsNullOrEmpty(r.Department) ? "—" : r.Department,
                    r.PunchTypeText,
                    string.IsNullOrEmpty(r.CardNo) ? "—" : r.CardNo);
            }
        }

        private void BindSummary()
        {
            gridSummary.Rows.Clear();
            for (int i = 0; i < _summaries.Count; i++)
            {
                AttendanceSummary s = _summaries[i];
                gridSummary.Rows.Add(
                    s.WorkDate,
                    s.EmpNo,
                    s.EmpName,
                    string.IsNullOrEmpty(s.Department) ? "—" : s.Department,
                    s.CheckInText,
                    s.CheckOutText,
                    s.DurationText,
                    s.StatusText);
            }
        }

        #endregion

        #region 导出

        private void btnExport_Click(object sender, EventArgs e)
        {
            bool isDetail = tabQuery.SelectedTab == tabDetail;

            if (isDetail && _details.Count == 0)
            {
                MessageBox.Show(this, "没有可以导出的明细数据，请先查询。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!isDetail && _summaries.Count == 0)
            {
                MessageBox.Show(this, "没有可以导出的汇总数据，请先查询。", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "CSV 文件 (*.csv)|*.csv|所有文件 (*.*)|*.*";
                dialog.FileName = string.Format("考勤{0}_{1}.csv",
                    isDetail ? "明细" : "汇总", DateTime.Now.ToString("yyyyMMdd_HHmm"));

                if (dialog.ShowDialog(this) != DialogResult.OK)
                {
                    return;
                }

                try
                {
                    StringBuilder sb = new StringBuilder();
                    if (isDetail)
                    {
                        sb.AppendLine("日期,时间,工号,姓名,部门,类型,卡号");
                        for (int i = 0; i < _details.Count; i++)
                        {
                            AttendanceRecord r = _details[i];
                            sb.AppendLine(string.Join(",",
                                Csv(r.WorkDate), Csv(r.PunchTime.ToShortTimeString()), Csv(r.EmpNo),
                                Csv(r.EmpName), Csv(r.Department), Csv(r.PunchTypeText), Csv(r.CardNo)));
                        }
                    }
                    else
                    {
                        sb.AppendLine("日期,工号,姓名,部门,上班时间,下班时间,在岗时长,状态");
                        for (int i = 0; i < _summaries.Count; i++)
                        {
                            AttendanceSummary s = _summaries[i];
                            sb.AppendLine(string.Join(",",
                                Csv(s.WorkDate), Csv(s.EmpNo), Csv(s.EmpName), Csv(s.Department),
                                Csv(s.CheckInText), Csv(s.CheckOutText), Csv(s.DurationText), Csv(s.StatusText)));
                        }
                    }

                    // 带 BOM 的 UTF-8，Excel 打开中文才不会乱码
                    File.WriteAllText(dialog.FileName, sb.ToString(), new UTF8Encoding(true));

                    MessageBox.Show(this, "导出成功：\r\n" + dialog.FileName, "导出完成",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    AppLog.Error("导出 CSV 失败", ex);
                    MessageBox.Show(this, "导出失败：" + ex.Message, "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static string Csv(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }
            if (value.IndexOf(',') >= 0 || value.IndexOf('"') >= 0 ||
                value.IndexOf('\n') >= 0 || value.IndexOf('\r') >= 0)
            {
                return "\"" + value.Replace("\"", "\"\"") + "\"";
            }
            return value;
        }

        #endregion
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmQuery.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmQuery
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelFilter = new System.Windows.Forms.Panel();
            this.labRange = new System.Windows.Forms.Label();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.labTo = new System.Windows.Forms.Label();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.labKeyword = new System.Windows.Forms.Label();
            this.txtKeyword = new System.Windows.Forms.TextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnExport = new System.Windows.Forms.Button();
            this.btnToday = new System.Windows.Forms.Button();
            this.btnThisMonth = new System.Windows.Forms.Button();
            this.tabQuery = new System.Windows.Forms.TabControl();
            this.tabDetail = new System.Windows.Forms.TabPage();
            this.gridDetail = new System.Windows.Forms.DataGridView();
            this.colDDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDEmpNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDDept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDCard = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabSummary = new System.Windows.Forms.TabPage();
            this.gridSummary = new System.Windows.Forms.DataGridView();
            this.colSDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSEmpNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSDept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSIn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSOut = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSDuration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelFoot = new System.Windows.Forms.Panel();
            this.labCount = new System.Windows.Forms.Label();
            this.panelFilter.SuspendLayout();
            this.tabQuery.SuspendLayout();
            this.tabDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDetail)).BeginInit();
            this.tabSummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridSummary)).BeginInit();
            this.panelFoot.SuspendLayout();
            this.SuspendLayout();
            //
            // panelFilter
            //
            this.panelFilter.BackColor = System.Drawing.Color.White;
            this.panelFilter.Controls.Add(this.labRange);
            this.panelFilter.Controls.Add(this.dtpFrom);
            this.panelFilter.Controls.Add(this.labTo);
            this.panelFilter.Controls.Add(this.dtpTo);
            this.panelFilter.Controls.Add(this.labKeyword);
            this.panelFilter.Controls.Add(this.txtKeyword);
            this.panelFilter.Controls.Add(this.btnQuery);
            this.panelFilter.Controls.Add(this.btnExport);
            this.panelFilter.Controls.Add(this.btnToday);
            this.panelFilter.Controls.Add(this.btnThisMonth);
            this.panelFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFilter.Location = new System.Drawing.Point(0, 0);
            this.panelFilter.Name = "panelFilter";
            this.panelFilter.Size = new System.Drawing.Size(948, 60);
            this.panelFilter.TabIndex = 0;
            //
            // labRange
            //
            this.labRange.AutoSize = true;
            this.labRange.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labRange.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labRange.Location = new System.Drawing.Point(16, 21);
            this.labRange.Name = "labRange";
            this.labRange.Size = new System.Drawing.Size(60, 17);
            this.labRange.TabIndex = 0;
            this.labRange.Text = "日期范围";
            //
            // dtpFrom
            //
            this.dtpFrom.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFrom.Location = new System.Drawing.Point(84, 17);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(124, 25);
            this.dtpFrom.TabIndex = 1;
            //
            // labTo
            //
            this.labTo.AutoSize = true;
            this.labTo.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labTo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labTo.Location = new System.Drawing.Point(214, 21);
            this.labTo.Name = "labTo";
            this.labTo.Size = new System.Drawing.Size(17, 17);
            this.labTo.TabIndex = 2;
            this.labTo.Text = "至";
            //
            // dtpTo
            //
            this.dtpTo.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTo.Location = new System.Drawing.Point(238, 17);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(124, 25);
            this.dtpTo.TabIndex = 3;
            //
            // labKeyword
            //
            this.labKeyword.AutoSize = true;
            this.labKeyword.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labKeyword.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labKeyword.Location = new System.Drawing.Point(374, 21);
            this.labKeyword.Name = "labKeyword";
            this.labKeyword.Size = new System.Drawing.Size(32, 17);
            this.labKeyword.TabIndex = 4;
            this.labKeyword.Text = "员工";
            //
            // txtKeyword
            //
            this.txtKeyword.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.txtKeyword.Location = new System.Drawing.Point(414, 17);
            this.txtKeyword.Name = "txtKeyword";
            this.txtKeyword.Size = new System.Drawing.Size(146, 25);
            this.txtKeyword.TabIndex = 5;
            //
            // btnQuery
            //
            this.btnQuery.Location = new System.Drawing.Point(570, 15);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(76, 30);
            this.btnQuery.TabIndex = 6;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            //
            // btnExport
            //
            this.btnExport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExport.Location = new System.Drawing.Point(656, 15);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(90, 30);
            this.btnExport.TabIndex = 7;
            this.btnExport.Text = "导出 CSV";
            this.btnExport.UseVisualStyleBackColor = true;
            //
            // btnToday
            //
            this.btnToday.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnToday.Location = new System.Drawing.Point(758, 15);
            this.btnToday.Name = "btnToday";
            this.btnToday.Size = new System.Drawing.Size(80, 30);
            this.btnToday.TabIndex = 8;
            this.btnToday.Text = "今天";
            this.btnToday.UseVisualStyleBackColor = true;
            //
            // btnThisMonth
            //
            this.btnThisMonth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThisMonth.Location = new System.Drawing.Point(846, 15);
            this.btnThisMonth.Name = "btnThisMonth";
            this.btnThisMonth.Size = new System.Drawing.Size(86, 30);
            this.btnThisMonth.TabIndex = 9;
            this.btnThisMonth.Text = "本月";
            this.btnThisMonth.UseVisualStyleBackColor = true;
            //
            // tabQuery
            //
            this.tabQuery.Controls.Add(this.tabDetail);
            this.tabQuery.Controls.Add(this.tabSummary);
            this.tabQuery.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabQuery.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.tabQuery.Location = new System.Drawing.Point(0, 60);
            this.tabQuery.Name = "tabQuery";
            this.tabQuery.SelectedIndex = 0;
            this.tabQuery.Size = new System.Drawing.Size(948, 500);
            this.tabQuery.TabIndex = 1;
            //
            // tabDetail
            //
            this.tabDetail.BackColor = System.Drawing.Color.White;
            this.tabDetail.Controls.Add(this.gridDetail);
            this.tabDetail.Location = new System.Drawing.Point(4, 26);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetail.Size = new System.Drawing.Size(940, 470);
            this.tabDetail.TabIndex = 0;
            this.tabDetail.Text = "打卡明细";
            //
            // gridDetail
            //
            this.gridDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDDate,
            this.colDTime,
            this.colDEmpNo,
            this.colDName,
            this.colDDept,
            this.colDType,
            this.colDCard});
            this.gridDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDetail.Location = new System.Drawing.Point(3, 3);
            this.gridDetail.Name = "gridDetail";
            this.gridDetail.Size = new System.Drawing.Size(934, 464);
            this.gridDetail.TabIndex = 0;
            //
            // colDDate
            //
            this.colDDate.HeaderText = "日期";
            this.colDDate.Name = "colDDate";
            //
            // colDTime
            //
            this.colDTime.HeaderText = "时间";
            this.colDTime.Name = "colDTime";
            //
            // colDEmpNo
            //
            this.colDEmpNo.HeaderText = "工号";
            this.colDEmpNo.Name = "colDEmpNo";
            //
            // colDName
            //
            this.colDName.HeaderText = "姓名";
            this.colDName.Name = "colDName";
            //
            // colDDept
            //
            this.colDDept.HeaderText = "部门";
            this.colDDept.Name = "colDDept";
            //
            // colDType
            //
            this.colDType.HeaderText = "类型";
            this.colDType.Name = "colDType";
            //
            // colDCard
            //
            this.colDCard.HeaderText = "卡号";
            this.colDCard.Name = "colDCard";
            //
            // tabSummary
            //
            this.tabSummary.BackColor = System.Drawing.Color.White;
            this.tabSummary.Controls.Add(this.gridSummary);
            this.tabSummary.Location = new System.Drawing.Point(4, 26);
            this.tabSummary.Name = "tabSummary";
            this.tabSummary.Padding = new System.Windows.Forms.Padding(3);
            this.tabSummary.Size = new System.Drawing.Size(940, 470);
            this.tabSummary.TabIndex = 1;
            this.tabSummary.Text = "按人按天汇总";
            //
            // gridSummary
            //
            this.gridSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridSummary.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colSDate,
            this.colSEmpNo,
            this.colSName,
            this.colSDept,
            this.colSIn,
            this.colSOut,
            this.colSDuration,
            this.colSStatus});
            this.gridSummary.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridSummary.Location = new System.Drawing.Point(3, 3);
            this.gridSummary.Name = "gridSummary";
            this.gridSummary.Size = new System.Drawing.Size(934, 464);
            this.gridSummary.TabIndex = 0;
            //
            // colSDate
            //
            this.colSDate.HeaderText = "日期";
            this.colSDate.Name = "colSDate";
            //
            // colSEmpNo
            //
            this.colSEmpNo.HeaderText = "工号";
            this.colSEmpNo.Name = "colSEmpNo";
            //
            // colSName
            //
            this.colSName.HeaderText = "姓名";
            this.colSName.Name = "colSName";
            //
            // colSDept
            //
            this.colSDept.HeaderText = "部门";
            this.colSDept.Name = "colSDept";
            //
            // colSIn
            //
            this.colSIn.HeaderText = "上班时间";
            this.colSIn.Name = "colSIn";
            //
            // colSOut
            //
            this.colSOut.HeaderText = "下班时间";
            this.colSOut.Name = "colSOut";
            //
            // colSDuration
            //
            this.colSDuration.HeaderText = "在岗时长";
            this.colSDuration.Name = "colSDuration";
            //
            // colSStatus
            //
            this.colSStatus.HeaderText = "状态";
            this.colSStatus.Name = "colSStatus";
            //
            // panelFoot
            //
            this.panelFoot.BackColor = System.Drawing.Color.White;
            this.panelFoot.Controls.Add(this.labCount);
            this.panelFoot.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFoot.Location = new System.Drawing.Point(0, 560);
            this.panelFoot.Name = "panelFoot";
            this.panelFoot.Size = new System.Drawing.Size(948, 32);
            this.panelFoot.TabIndex = 2;
            //
            // labCount
            //
            this.labCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labCount.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labCount.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labCount.Location = new System.Drawing.Point(0, 0);
            this.labCount.Name = "labCount";
            this.labCount.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.labCount.Size = new System.Drawing.Size(948, 32);
            this.labCount.TabIndex = 0;
            this.labCount.Text = "尚未查询";
            this.labCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // FrmQuery
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.ClientSize = new System.Drawing.Size(948, 592);
            this.Controls.Add(this.tabQuery);
            this.Controls.Add(this.panelFoot);
            this.Controls.Add(this.panelFilter);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.Name = "FrmQuery";
            this.panelFilter.ResumeLayout(false);
            this.panelFilter.PerformLayout();
            this.tabQuery.ResumeLayout(false);
            this.tabDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDetail)).EndInit();
            this.tabSummary.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridSummary)).EndInit();
            this.panelFoot.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelFilter;
        private System.Windows.Forms.Label labRange;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private System.Windows.Forms.Label labTo;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.Label labKeyword;
        private System.Windows.Forms.TextBox txtKeyword;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Button btnToday;
        private System.Windows.Forms.Button btnThisMonth;
        private System.Windows.Forms.TabControl tabQuery;
        private System.Windows.Forms.TabPage tabDetail;
        private System.Windows.Forms.DataGridView gridDetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDEmpNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDDept;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDType;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDCard;
        private System.Windows.Forms.TabPage tabSummary;
        private System.Windows.Forms.DataGridView gridSummary;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSEmpNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSDept;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSIn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSOut;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSDuration;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSStatus;
        private System.Windows.Forms.Panel panelFoot;
        private System.Windows.Forms.Label labCount;
    }
}
