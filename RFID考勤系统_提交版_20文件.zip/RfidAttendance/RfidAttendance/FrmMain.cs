﻿// 主窗体：导航 + 内容区 + 状态栏
using System;
using System.Threading;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Hardware;
using RfidAttendance.Services;

// ---------------------------------------------------------------
// 来源：Forms\FrmMain.cs
// ---------------------------------------------------------------
// System.Threading 和 System.Windows.Forms 里都有 Timer，这里显式指定用界面计时器
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 主窗体：左侧导航 + 右侧内容区 + 状态栏。
    /// 四个功能页面以无边框子窗体的形式嵌入到 panelContent 中。
    /// </summary>
    public partial class FrmMain : Form
    {
        private readonly RfidReaderService _reader = RfidReaderService.Instance;
        private readonly AttendanceService _attendance = new AttendanceService();

        private FrmCheckIn _pageCheckIn;
        private FrmEmployee _pageEmployee;
        private FrmQuery _pageQuery;
        private FrmSettings _pageSettings;

        private Form _currentPage;
        private ITagConsumer _tagConsumer;
        private Timer _clockTimer;

        public FrmMain()
        {
            InitializeComponent();
            AppTheme.ApplyForm(this);

            // 导航按钮事件在这里绑定，避免设计器文件被重新生成时丢失
            btnNavCheckIn.Click += btnNavCheckIn_Click;
            btnNavEmployee.Click += btnNavEmployee_Click;
            btnNavQuery.Click += btnNavQuery_Click;
            btnNavSettings.Click += btnNavSettings_Click;

            _reader.TagRead += OnReaderTagRead;
            _reader.StatusChanged += OnReaderStatusChanged;

            _clockTimer = new Timer();
            _clockTimer.Interval = 1000;
            _clockTimer.Tick += OnClockTick;
            _clockTimer.Start();

            Load += OnMainLoad;
            FormClosing += OnMainClosing;
        }

        #region 生命周期

        private void OnMainLoad(object sender, EventArgs e)
        {
            // 先把四个页面都建出来，切换时不再重新构造，响应更快
            _pageCheckIn = new FrmCheckIn();
            _pageEmployee = new FrmEmployee(this);
            _pageQuery = new FrmQuery();
            _pageSettings = new FrmSettings(this);

            UpdateReaderStatus(false, "读卡器未连接", false);
            UpdateTodayStats();

            ShowPage(_pageCheckIn, "打卡签到", btnNavCheckIn);

            // 后台尝试自动连接读卡器，不阻塞界面
            ThreadPool.QueueUserWorkItem(delegate { TryAutoConnect(); });
        }

        private void OnMainClosing(object sender, FormClosingEventArgs e)
        {
            if (_clockTimer != null)
            {
                _clockTimer.Stop();
                _clockTimer.Dispose();
                _clockTimer = null;
            }

            _reader.TagRead -= OnReaderTagRead;
            _reader.StatusChanged -= OnReaderStatusChanged;

            try
            {
                _reader.Close();
            }
            catch (Exception ex)
            {
                AppLog.Error("关闭读卡器失败", ex);
            }
        }

        private void OnClockTick(object sender, EventArgs e)
        {
            UpdateTodayStats();
        }

        #endregion

        #region 导航

        /// <summary>把页面嵌进内容区并显示。</summary>
        private void ShowPage(Form page, string title, Button navButton)
        {
            if (page == null || page == _currentPage)
            {
                return;
            }

            panelContent.SuspendLayout();

            if (_currentPage != null)
            {
                _currentPage.Hide();
            }

            if (page.Parent != panelContent)
            {
                page.TopLevel = false;
                page.FormBorderStyle = FormBorderStyle.None;
                page.Dock = DockStyle.Fill;
                page.BackColor = AppTheme.Background;
                panelContent.Controls.Add(page);
            }

            _currentPage = page;
            page.Show();
            page.BringToFront();
            panelContent.ResumeLayout();

            labPageTitle.Text = title;
            HighlightNavButton(navButton);

            IPageView view = page as IPageView;
            if (view != null)
            {
                try
                {
                    view.OnPageShown();
                }
                catch (Exception ex)
                {
                    AppLog.Error("刷新页面数据失败", ex);
                }
            }
        }

        private void HighlightNavButton(Button active)
        {
            Button[] buttons = new Button[] { btnNavCheckIn, btnNavEmployee, btnNavQuery, btnNavSettings };
            for (int i = 0; i < buttons.Length; i++)
            {
                bool selected = buttons[i] == active;
                buttons[i].BackColor = selected ? AppTheme.Primary : AppTheme.NavBackground;
                buttons[i].ForeColor = selected ? System.Drawing.Color.White : System.Drawing.Color.FromArgb(203, 213, 225);
            }
        }

        private void btnNavCheckIn_Click(object sender, EventArgs e)
        {
            ShowPage(_pageCheckIn, "打卡签到", btnNavCheckIn);
        }

        private void btnNavEmployee_Click(object sender, EventArgs e)
        {
            ShowPage(_pageEmployee, "员工管理", btnNavEmployee);
        }

        private void btnNavQuery_Click(object sender, EventArgs e)
        {
            ShowPage(_pageQuery, "考勤查询", btnNavQuery);
        }

        private void btnNavSettings_Click(object sender, EventArgs e)
        {
            ShowPage(_pageSettings, "设备设置", btnNavSettings);
        }

        #endregion

        #region 读卡器与刷卡分发

        /// <summary>供 FrmEmployeeEdit 等窗口临时独占刷卡事件。</summary>
        public void SetTagConsumer(ITagConsumer consumer)
        {
            _tagConsumer = consumer;
        }

        private void OnReaderTagRead(object sender, TagReadEventArgs e)
        {
            if (IsDisposed || !IsHandleCreated)
            {
                return;
            }
            try
            {
                BeginInvoke(new Action<string>(DispatchTag), e.CardNo);
            }
            catch (InvalidOperationException)
            {
                // 窗体正在销毁，忽略
            }
        }

        private void DispatchTag(string epc)
        {
            ITagConsumer consumer = _tagConsumer;
            if (consumer != null)
            {
                consumer.HandleTag(epc);
                return;
            }

            ITagConsumer page = _currentPage as ITagConsumer;
            if (page != null)
            {
                page.HandleTag(epc);
            }
        }

        private void OnReaderStatusChanged(object sender, ReaderStatusEventArgs e)
        {
            if (IsDisposed || !IsHandleCreated)
            {
                return;
            }
            try
            {
                BeginInvoke(new Action<bool, string, bool>(UpdateReaderStatus),
                    e.Connected, e.Message, e.IsError);
            }
            catch (InvalidOperationException)
            {
            }
        }

        private void UpdateReaderStatus(bool connected, string message, bool isError)
        {
            labReaderStatus.Text = message;

            if (isError)
            {
                labReaderStatus.ForeColor = AppTheme.Danger;
                labReaderDot.ForeColor = AppTheme.Danger;
            }
            else if (connected)
            {
                labReaderStatus.ForeColor = AppTheme.Success;
                labReaderDot.ForeColor = AppTheme.Success;
            }
            else
            {
                labReaderStatus.ForeColor = AppTheme.TextSecondary;
                labReaderDot.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            }

            SetStatus(message);
        }

        /// <summary>启动后在后台尝试连接读卡器。</summary>
        private void TryAutoConnect()
        {
            try
            {
                string port = SettingsStore.Get(SettingsStore.KeyPort, string.Empty);
                int baud = SettingsStore.GetInt(SettingsStore.KeyBaudIndex, 3);

                string error;
                bool ok = _reader.Open(port, baud, out error);
                if (ok)
                {
                    _reader.StartInventory();
                    return;
                }

                AppLog.Info("自动连接读卡器未成功：" + error);

                // 只有「没插读卡器」之外的失败才提示，避免每次启动都弹窗
                if (port.Length > 0 && IsHandleCreated && !IsDisposed)
                {
                    try
                    {
                        BeginInvoke(new Action<string>(SetStatus), "读卡器未连接：" + error);
                    }
                    catch (InvalidOperationException)
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Error("自动连接读卡器异常", ex);
            }
        }

        /// <summary>供设置页调用：重新连接读卡器。</summary>
        public bool ConnectReader(string port, int baudIndex, out string error)
        {
            bool ok = _reader.Open(port, baudIndex, out error);
            if (ok)
            {
                _reader.StartInventory();
            }
            return ok;
        }

        /// <summary>供设置页调用：断开读卡器。</summary>
        public void DisconnectReader()
        {
            _reader.Close();
        }

        public RfidReaderService Reader
        {
            get { return _reader; }
        }

        #endregion

        #region 状态栏

        /// <summary>更新左下角状态文本。</summary>
        public void SetStatus(string message)
        {
            labStatusLeft.Text = message;
        }

        private void UpdateTodayStats()
        {
            try
            {
                int people = _attendance.GetTodayPeopleCount();
                int records = _attendance.GetTodayRecordCount();
                int total = new EmployeeRepository().Count();
                labStatusRight.Text = string.Format(
                    "{0}  |  今日 {1}/{2} 人已打卡，共 {3} 笔",
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), people, total, records);
            }
            catch (Exception)
            {
                labStatusRight.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

        #endregion
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmMain.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelNav = new System.Windows.Forms.Panel();
            this.labBrand = new System.Windows.Forms.Label();
            this.btnNavCheckIn = new System.Windows.Forms.Button();
            this.btnNavEmployee = new System.Windows.Forms.Button();
            this.btnNavQuery = new System.Windows.Forms.Button();
            this.btnNavSettings = new System.Windows.Forms.Button();
            this.labNavVersion = new System.Windows.Forms.Label();
            this.panelBody = new System.Windows.Forms.Panel();
            this.panelContent = new System.Windows.Forms.Panel();
            this.panelStatus = new System.Windows.Forms.Panel();
            this.labStatusRight = new System.Windows.Forms.Label();
            this.labStatusLeft = new System.Windows.Forms.Label();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.labPageTitle = new System.Windows.Forms.Label();
            this.labReaderStatus = new System.Windows.Forms.Label();
            this.labReaderDot = new System.Windows.Forms.Label();
            this.panelNav.SuspendLayout();
            this.panelBody.SuspendLayout();
            this.panelStatus.SuspendLayout();
            this.panelHeader.SuspendLayout();
            this.SuspendLayout();
            //
            // panelNav
            //
            this.panelNav.BackColor = System.Drawing.Color.FromArgb(30, 41, 59);
            this.panelNav.Controls.Add(this.btnNavSettings);
            this.panelNav.Controls.Add(this.btnNavQuery);
            this.panelNav.Controls.Add(this.btnNavEmployee);
            this.panelNav.Controls.Add(this.btnNavCheckIn);
            this.panelNav.Controls.Add(this.labBrand);
            this.panelNav.Controls.Add(this.labNavVersion);
            this.panelNav.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelNav.Location = new System.Drawing.Point(0, 0);
            this.panelNav.Name = "panelNav";
            this.panelNav.Size = new System.Drawing.Size(200, 720);
            this.panelNav.TabIndex = 0;
            //
            // labBrand
            //
            this.labBrand.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.labBrand.ForeColor = System.Drawing.Color.White;
            this.labBrand.Location = new System.Drawing.Point(0, 0);
            this.labBrand.Name = "labBrand";
            this.labBrand.Size = new System.Drawing.Size(200, 72);
            this.labBrand.TabIndex = 0;
            this.labBrand.Text = "RFID 考勤系统";
            this.labBrand.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // btnNavCheckIn
            //
            this.btnNavCheckIn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavCheckIn.FlatAppearance.BorderSize = 0;
            this.btnNavCheckIn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnNavCheckIn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.btnNavCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavCheckIn.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.btnNavCheckIn.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.btnNavCheckIn.Location = new System.Drawing.Point(0, 84);
            this.btnNavCheckIn.Name = "btnNavCheckIn";
            this.btnNavCheckIn.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnNavCheckIn.Size = new System.Drawing.Size(200, 48);
            this.btnNavCheckIn.TabIndex = 1;
            this.btnNavCheckIn.Text = "打卡签到";
            this.btnNavCheckIn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavCheckIn.UseVisualStyleBackColor = false;
            //
            // btnNavEmployee
            //
            this.btnNavEmployee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavEmployee.FlatAppearance.BorderSize = 0;
            this.btnNavEmployee.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnNavEmployee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.btnNavEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavEmployee.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.btnNavEmployee.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.btnNavEmployee.Location = new System.Drawing.Point(0, 132);
            this.btnNavEmployee.Name = "btnNavEmployee";
            this.btnNavEmployee.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnNavEmployee.Size = new System.Drawing.Size(200, 48);
            this.btnNavEmployee.TabIndex = 2;
            this.btnNavEmployee.Text = "员工管理";
            this.btnNavEmployee.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavEmployee.UseVisualStyleBackColor = false;
            //
            // btnNavQuery
            //
            this.btnNavQuery.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavQuery.FlatAppearance.BorderSize = 0;
            this.btnNavQuery.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnNavQuery.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.btnNavQuery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavQuery.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.btnNavQuery.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.btnNavQuery.Location = new System.Drawing.Point(0, 180);
            this.btnNavQuery.Name = "btnNavQuery";
            this.btnNavQuery.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnNavQuery.Size = new System.Drawing.Size(200, 48);
            this.btnNavQuery.TabIndex = 3;
            this.btnNavQuery.Text = "考勤查询";
            this.btnNavQuery.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavQuery.UseVisualStyleBackColor = false;
            //
            // btnNavSettings
            //
            this.btnNavSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNavSettings.FlatAppearance.BorderSize = 0;
            this.btnNavSettings.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.btnNavSettings.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.btnNavSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNavSettings.Font = new System.Drawing.Font("微软雅黑", 10F);
            this.btnNavSettings.ForeColor = System.Drawing.Color.FromArgb(203, 213, 225);
            this.btnNavSettings.Location = new System.Drawing.Point(0, 228);
            this.btnNavSettings.Name = "btnNavSettings";
            this.btnNavSettings.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btnNavSettings.Size = new System.Drawing.Size(200, 48);
            this.btnNavSettings.TabIndex = 4;
            this.btnNavSettings.Text = "设备设置";
            this.btnNavSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavSettings.UseVisualStyleBackColor = false;
            //
            // labNavVersion
            //
            this.labNavVersion.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labNavVersion.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labNavVersion.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labNavVersion.Location = new System.Drawing.Point(0, 682);
            this.labNavVersion.Name = "labNavVersion";
            this.labNavVersion.Size = new System.Drawing.Size(200, 38);
            this.labNavVersion.TabIndex = 5;
            this.labNavVersion.Text = "KL9007U · v1.0";
            this.labNavVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // panelBody
            //
            this.panelBody.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.panelBody.Controls.Add(this.panelContent);
            this.panelBody.Controls.Add(this.panelStatus);
            this.panelBody.Controls.Add(this.panelHeader);
            this.panelBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBody.Location = new System.Drawing.Point(200, 0);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(980, 720);
            this.panelBody.TabIndex = 1;
            //
            // panelContent
            //
            this.panelContent.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.panelContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContent.Location = new System.Drawing.Point(0, 64);
            this.panelContent.Name = "panelContent";
            this.panelContent.Padding = new System.Windows.Forms.Padding(16);
            this.panelContent.Size = new System.Drawing.Size(980, 624);
            this.panelContent.TabIndex = 2;
            //
            // panelStatus
            //
            this.panelStatus.BackColor = System.Drawing.Color.White;
            this.panelStatus.Controls.Add(this.labStatusRight);
            this.panelStatus.Controls.Add(this.labStatusLeft);
            this.panelStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelStatus.Location = new System.Drawing.Point(0, 688);
            this.panelStatus.Name = "panelStatus";
            this.panelStatus.Size = new System.Drawing.Size(980, 32);
            this.panelStatus.TabIndex = 1;
            //
            // labStatusRight
            //
            this.labStatusRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.labStatusRight.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labStatusRight.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labStatusRight.Location = new System.Drawing.Point(480, 0);
            this.labStatusRight.Name = "labStatusRight";
            this.labStatusRight.Padding = new System.Windows.Forms.Padding(0, 0, 24, 0);
            this.labStatusRight.Size = new System.Drawing.Size(500, 32);
            this.labStatusRight.TabIndex = 1;
            this.labStatusRight.Text = "—";
            this.labStatusRight.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // labStatusLeft
            //
            this.labStatusLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.labStatusLeft.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labStatusLeft.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labStatusLeft.Location = new System.Drawing.Point(0, 0);
            this.labStatusLeft.Name = "labStatusLeft";
            this.labStatusLeft.Padding = new System.Windows.Forms.Padding(24, 0, 0, 0);
            this.labStatusLeft.Size = new System.Drawing.Size(480, 32);
            this.labStatusLeft.TabIndex = 0;
            this.labStatusLeft.Text = "就绪";
            this.labStatusLeft.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            //
            // panelHeader
            //
            this.panelHeader.BackColor = System.Drawing.Color.White;
            this.panelHeader.Controls.Add(this.labReaderStatus);
            this.panelHeader.Controls.Add(this.labReaderDot);
            this.panelHeader.Controls.Add(this.labPageTitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Location = new System.Drawing.Point(0, 0);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(980, 64);
            this.panelHeader.TabIndex = 0;
            //
            // labPageTitle
            //
            this.labPageTitle.AutoSize = true;
            this.labPageTitle.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Bold);
            this.labPageTitle.ForeColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.labPageTitle.Location = new System.Drawing.Point(26, 18);
            this.labPageTitle.Name = "labPageTitle";
            this.labPageTitle.Size = new System.Drawing.Size(120, 30);
            this.labPageTitle.TabIndex = 0;
            this.labPageTitle.Text = "打卡签到";
            //
            // labReaderDot
            //
            this.labReaderDot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labReaderDot.Font = new System.Drawing.Font("微软雅黑", 11F);
            this.labReaderDot.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labReaderDot.Location = new System.Drawing.Point(640, 22);
            this.labReaderDot.Name = "labReaderDot";
            this.labReaderDot.Size = new System.Drawing.Size(20, 22);
            this.labReaderDot.TabIndex = 1;
            this.labReaderDot.Text = "●";
            this.labReaderDot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //
            // labReaderStatus
            //
            this.labReaderStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labReaderStatus.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.labReaderStatus.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.labReaderStatus.Location = new System.Drawing.Point(662, 20);
            this.labReaderStatus.Name = "labReaderStatus";
            this.labReaderStatus.Size = new System.Drawing.Size(292, 26);
            this.labReaderStatus.TabIndex = 2;
            this.labReaderStatus.Text = "读卡器未连接";
            this.labReaderStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            //
            // FrmMain
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(243, 246, 251);
            this.ClientSize = new System.Drawing.Size(1180, 720);
            this.Controls.Add(this.panelBody);
            this.Controls.Add(this.panelNav);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.MinimumSize = new System.Drawing.Size(1024, 640);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RFID 考勤管理系统";
            this.panelNav.ResumeLayout(false);
            this.panelBody.ResumeLayout(false);
            this.panelStatus.ResumeLayout(false);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelNav;
        private System.Windows.Forms.Label labBrand;
        private System.Windows.Forms.Button btnNavCheckIn;
        private System.Windows.Forms.Button btnNavEmployee;
        private System.Windows.Forms.Button btnNavQuery;
        private System.Windows.Forms.Button btnNavSettings;
        private System.Windows.Forms.Label labNavVersion;
        private System.Windows.Forms.Panel panelBody;
        private System.Windows.Forms.Panel panelContent;
        private System.Windows.Forms.Panel panelStatus;
        private System.Windows.Forms.Label labStatusLeft;
        private System.Windows.Forms.Label labStatusRight;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Label labPageTitle;
        private System.Windows.Forms.Label labReaderStatus;
        private System.Windows.Forms.Label labReaderDot;
    }
}
