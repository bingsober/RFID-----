﻿// 员工新增/编辑弹窗
using System;
using System.Drawing;
using System.Windows.Forms;
using RfidAttendance.Common;
using RfidAttendance.Data;
using RfidAttendance.Hardware;
using RfidAttendance.Models;

// ---------------------------------------------------------------
// 来源：Forms\FrmEmployeeEdit.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    /// <summary>
    /// 员工信息编辑弹窗：新增或修改一名员工的资料，并可直接刷卡读取卡号。
    /// </summary>
    public partial class FrmEmployeeEdit : Form, ITagConsumer
    {
        private readonly EmployeeRepository _repo = new EmployeeRepository();
        private readonly FrmMain _main;
        private readonly Employee _editing;
        private readonly bool _isNew;

        private bool _waitingCard;

        /// <summary>供 Visual Studio 设计器使用。</summary>
        public FrmEmployeeEdit()
            : this(null, null)
        {
        }

        /// <summary>
        /// </summary>
        /// <param name="employee">要编辑的员工；为 null 表示新增。</param>
        /// <param name="main">主窗体，用于临时接管刷卡事件。</param>
        public FrmEmployeeEdit(Employee employee, FrmMain main)
        {
            InitializeComponent();

            _main = main;
            _editing = employee;
            _isNew = employee == null;

            AppTheme.ApplyForm(this);
            this.BackColor = Color.White;
            AppTheme.StylePrimaryButton(btnOk);
            AppTheme.StyleSecondaryButton(btnCancel);
            AppTheme.StyleSecondaryButton(btnReadCard);

            btnOk.Click += btnOk_Click;
            btnReadCard.Click += btnReadCard_Click;
            FormClosed += OnEditClosed;

            if (_isNew)
            {
                this.Text = "新增员工";
                chkActive.Checked = true;
            }
            else
            {
                this.Text = "编辑员工 —— " + employee.Name;
                txtEmpNo.Text = employee.EmpNo;
                txtName.Text = employee.Name;
                txtDept.Text = employee.Department;
                txtPosition.Text = employee.Position;
                txtCard.Text = employee.CardNo;
                txtPhone.Text = employee.Phone;
                txtRemark.Text = employee.Remark;
                chkActive.Checked = employee.IsActive;
            }
        }

        private void OnEditClosed(object sender, FormClosedEventArgs e)
        {
            // 无论怎样退出，都要把刷卡事件还给主界面
            StopWaitingCard();
        }

        #region 刷卡读取卡号

        private void btnReadCard_Click(object sender, EventArgs e)
        {
            if (_waitingCard)
            {
                StopWaitingCard();
                labTip.ForeColor = AppTheme.TextSecondary;
                labTip.Text = "已取消读卡。";
                return;
            }

            if (!RfidReaderService.Instance.IsOpen)
            {
                MessageBox.Show(this,
                    "读卡器还没有连接。\r\n\r\n请先到「设备设置」页面连接读卡器，或者手动输入卡号。",
                    "读卡器未连接", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (_main != null)
            {
                _main.SetTagConsumer(this);
            }

            _waitingCard = true;
            btnReadCard.Text = "取消读卡";
            labTip.ForeColor = AppTheme.Primary;
            labTip.Text = "正在等待刷卡……请把卡片靠近读卡器。已有的卡号会被覆盖。";
        }

        private void StopWaitingCard()
        {
            if (!_waitingCard)
            {
                return;
            }
            _waitingCard = false;
            if (_main != null)
            {
                _main.SetTagConsumer(null);
            }
            btnReadCard.Text = "刷卡读取";
        }

        /// <summary>读卡模式下由主窗体转发刷卡事件。</summary>
        public void HandleTag(string epc)
        {
            if (!_waitingCard)
            {
                return;
            }

            StopWaitingCard();
            txtCard.Text = HexUtil.Normalize(epc);
            labTip.ForeColor = AppTheme.Success;
            labTip.Text = "已读取卡号：" + txtCard.Text + "（保存后生效）";
        }

        #endregion

        #region 保存

        private void btnOk_Click(object sender, EventArgs e)
        {
            string empNo = txtEmpNo.Text.Trim();
            string name = txtName.Text.Trim();
            string card = HexUtil.Normalize(txtCard.Text);

            if (empNo.Length == 0)
            {
                Warn("请填写工号。", txtEmpNo);
                return;
            }
            if (name.Length == 0)
            {
                Warn("请填写姓名。", txtName);
                return;
            }
            if (card.Length > 0 && HexUtil.FromHexString(card) == null)
            {
                Warn("卡号必须是十六进制字符（0-9、A-F），或留空。", txtCard);
                return;
            }

            int excludeId = _isNew ? 0 : _editing.Id;

            try
            {
                if (_repo.EmpNoExists(empNo, excludeId))
                {
                    Warn("工号「" + empNo + "」已经被其他员工使用了。", txtEmpNo);
                    return;
                }

                if (card.Length > 0 && _repo.CardNoExists(card, excludeId))
                {
                    Employee owner = _repo.GetByCardNo(card);
                    Warn("这张卡已经绑定给 " + (owner != null ? owner.Name : "其他员工") + " 了。", txtCard);
                    return;
                }

                if (_isNew)
                {
                    Employee created = new Employee();
                    Fill(created, empNo, name, card);
                    _repo.Insert(created);
                    AppLog.Info("新增员工：" + created.EmpNo + " " + created.Name);
                }
                else
                {
                    Fill(_editing, empNo, name, card);
                    _repo.Update(_editing);
                    AppLog.Info("更新员工：" + _editing.EmpNo + " " + _editing.Name);
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                AppLog.Error("保存员工信息失败", ex);
                MessageBox.Show(this, "保存失败：" + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Fill(Employee target, string empNo, string name, string card)
        {
            target.EmpNo = empNo;
            target.Name = name;
            target.Department = txtDept.Text.Trim();
            target.Position = txtPosition.Text.Trim();
            target.CardNo = card;
            target.Phone = txtPhone.Text.Trim();
            target.Remark = txtRemark.Text.Trim();
            target.IsActive = chkActive.Checked;
        }

        private void Warn(string message, Control focusControl)
        {
            MessageBox.Show(this, message, "请检查填写", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            if (focusControl != null)
            {
                focusControl.Focus();
            }
        }

        #endregion
    }
}

// ---------------------------------------------------------------
// 来源：Forms\FrmEmployeeEdit.Designer.cs
// ---------------------------------------------------------------
namespace RfidAttendance.Forms
{
    partial class FrmEmployeeEdit
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.labEmpNo = new System.Windows.Forms.Label();
            this.txtEmpNo = new System.Windows.Forms.TextBox();
            this.labName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.labDept = new System.Windows.Forms.Label();
            this.txtDept = new System.Windows.Forms.TextBox();
            this.labPosition = new System.Windows.Forms.Label();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.labCard = new System.Windows.Forms.Label();
            this.txtCard = new System.Windows.Forms.TextBox();
            this.btnReadCard = new System.Windows.Forms.Button();
            this.labPhone = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.labRemark = new System.Windows.Forms.Label();
            this.txtRemark = new System.Windows.Forms.TextBox();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.labTip = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // labEmpNo
            //
            this.labEmpNo.AutoSize = true;
            this.labEmpNo.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labEmpNo.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labEmpNo.Location = new System.Drawing.Point(26, 28);
            this.labEmpNo.Name = "labEmpNo";
            this.labEmpNo.Size = new System.Drawing.Size(44, 17);
            this.labEmpNo.TabIndex = 0;
            this.labEmpNo.Text = "工号 *";
            //
            // txtEmpNo
            //
            this.txtEmpNo.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtEmpNo.Location = new System.Drawing.Point(116, 24);
            this.txtEmpNo.Name = "txtEmpNo";
            this.txtEmpNo.Size = new System.Drawing.Size(300, 25);
            this.txtEmpNo.TabIndex = 1;
            //
            // labName
            //
            this.labName.AutoSize = true;
            this.labName.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labName.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labName.Location = new System.Drawing.Point(26, 66);
            this.labName.Name = "labName";
            this.labName.Size = new System.Drawing.Size(44, 17);
            this.labName.TabIndex = 2;
            this.labName.Text = "姓名 *";
            //
            // txtName
            //
            this.txtName.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtName.Location = new System.Drawing.Point(116, 62);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(300, 25);
            this.txtName.TabIndex = 3;
            //
            // labDept
            //
            this.labDept.AutoSize = true;
            this.labDept.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labDept.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labDept.Location = new System.Drawing.Point(26, 104);
            this.labDept.Name = "labDept";
            this.labDept.Size = new System.Drawing.Size(44, 17);
            this.labDept.TabIndex = 4;
            this.labDept.Text = "部门";
            //
            // txtDept
            //
            this.txtDept.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtDept.Location = new System.Drawing.Point(116, 100);
            this.txtDept.Name = "txtDept";
            this.txtDept.Size = new System.Drawing.Size(300, 25);
            this.txtDept.TabIndex = 5;
            //
            // labPosition
            //
            this.labPosition.AutoSize = true;
            this.labPosition.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labPosition.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labPosition.Location = new System.Drawing.Point(26, 142);
            this.labPosition.Name = "labPosition";
            this.labPosition.Size = new System.Drawing.Size(44, 17);
            this.labPosition.TabIndex = 6;
            this.labPosition.Text = "职位";
            //
            // txtPosition
            //
            this.txtPosition.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtPosition.Location = new System.Drawing.Point(116, 138);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(300, 25);
            this.txtPosition.TabIndex = 7;
            //
            // labCard
            //
            this.labCard.AutoSize = true;
            this.labCard.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labCard.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labCard.Location = new System.Drawing.Point(26, 180);
            this.labCard.Name = "labCard";
            this.labCard.Size = new System.Drawing.Size(70, 17);
            this.labCard.TabIndex = 8;
            this.labCard.Text = "卡号 (EPC)";
            //
            // txtCard
            //
            this.txtCard.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.txtCard.Location = new System.Drawing.Point(116, 176);
            this.txtCard.Name = "txtCard";
            this.txtCard.Size = new System.Drawing.Size(206, 24);
            this.txtCard.TabIndex = 9;
            //
            // btnReadCard
            //
            this.btnReadCard.Location = new System.Drawing.Point(328, 175);
            this.btnReadCard.Name = "btnReadCard";
            this.btnReadCard.Size = new System.Drawing.Size(88, 26);
            this.btnReadCard.TabIndex = 10;
            this.btnReadCard.Text = "刷卡读取";
            this.btnReadCard.UseVisualStyleBackColor = true;
            //
            // labPhone
            //
            this.labPhone.AutoSize = true;
            this.labPhone.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labPhone.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labPhone.Location = new System.Drawing.Point(26, 218);
            this.labPhone.Name = "labPhone";
            this.labPhone.Size = new System.Drawing.Size(44, 17);
            this.labPhone.TabIndex = 11;
            this.labPhone.Text = "电话";
            //
            // txtPhone
            //
            this.txtPhone.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtPhone.Location = new System.Drawing.Point(116, 214);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(300, 25);
            this.txtPhone.TabIndex = 12;
            //
            // labRemark
            //
            this.labRemark.AutoSize = true;
            this.labRemark.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.labRemark.ForeColor = System.Drawing.Color.FromArgb(71, 85, 105);
            this.labRemark.Location = new System.Drawing.Point(26, 256);
            this.labRemark.Name = "labRemark";
            this.labRemark.Size = new System.Drawing.Size(44, 17);
            this.labRemark.TabIndex = 13;
            this.labRemark.Text = "备注";
            //
            // txtRemark
            //
            this.txtRemark.Font = new System.Drawing.Font("微软雅黑", 9.5F);
            this.txtRemark.Location = new System.Drawing.Point(116, 252);
            this.txtRemark.Multiline = true;
            this.txtRemark.Name = "txtRemark";
            this.txtRemark.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemark.Size = new System.Drawing.Size(300, 66);
            this.txtRemark.TabIndex = 14;
            //
            // chkActive
            //
            this.chkActive.AutoSize = true;
            this.chkActive.Checked = true;
            this.chkActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActive.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.chkActive.ForeColor = System.Drawing.Color.FromArgb(51, 65, 85);
            this.chkActive.Location = new System.Drawing.Point(116, 328);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(160, 21);
            this.chkActive.TabIndex = 15;
            this.chkActive.Text = "启用（停用后不能打卡）";
            this.chkActive.UseVisualStyleBackColor = true;
            //
            // labTip
            //
            this.labTip.Font = new System.Drawing.Font("微软雅黑", 8.5F);
            this.labTip.ForeColor = System.Drawing.Color.FromArgb(148, 163, 184);
            this.labTip.Location = new System.Drawing.Point(26, 358);
            this.labTip.Name = "labTip";
            this.labTip.Size = new System.Drawing.Size(390, 36);
            this.labTip.TabIndex = 16;
            this.labTip.Text = "带 * 的为必填项。卡号可以留空，之后在员工列表里刷卡绑定。";
            //
            // btnOk
            //
            this.btnOk.Location = new System.Drawing.Point(236, 400);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(88, 34);
            this.btnOk.TabIndex = 17;
            this.btnOk.Text = "保存";
            this.btnOk.UseVisualStyleBackColor = true;
            //
            // btnCancel
            //
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(332, 400);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 34);
            this.btnCancel.TabIndex = 18;
            this.btnCancel.Text = "取消";
            this.btnCancel.UseVisualStyleBackColor = true;
            //
            // FrmEmployeeEdit
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(444, 452);
            this.Controls.Add(this.labEmpNo);
            this.Controls.Add(this.txtEmpNo);
            this.Controls.Add(this.labName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.labDept);
            this.Controls.Add(this.txtDept);
            this.Controls.Add(this.labPosition);
            this.Controls.Add(this.txtPosition);
            this.Controls.Add(this.labCard);
            this.Controls.Add(this.txtCard);
            this.Controls.Add(this.btnReadCard);
            this.Controls.Add(this.labPhone);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.labRemark);
            this.Controls.Add(this.txtRemark);
            this.Controls.Add(this.chkActive);
            this.Controls.Add(this.labTip);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnCancel);
            this.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmEmployeeEdit";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "员工信息";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label labEmpNo;
        private System.Windows.Forms.TextBox txtEmpNo;
        private System.Windows.Forms.Label labName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label labDept;
        private System.Windows.Forms.TextBox txtDept;
        private System.Windows.Forms.Label labPosition;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.Label labCard;
        private System.Windows.Forms.TextBox txtCard;
        private System.Windows.Forms.Button btnReadCard;
        private System.Windows.Forms.Label labPhone;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label labRemark;
        private System.Windows.Forms.TextBox txtRemark;
        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.Label labTip;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
    }
}
